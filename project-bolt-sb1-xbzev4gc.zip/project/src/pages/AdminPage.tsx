import { useEffect, useState, type ReactNode } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Loader2,
  Save,
  Trophy,
  Target,
  Flag,
  Goal,
  ChevronDown,
  ChevronRight,
  Shield,
  AlertCircle,
  TrendingUp,
  Check,
  Star,
  Calendar,
  BarChart3,
  Clock,
  ListPlus,
  Trash2 as Trash2Icon,
  Download,
  Search,
  CheckCircle,
  Users,
  KeyRound,
  Copy,
  UserCheck,
  UserX,
  RefreshCw,
  Sparkles,
  LayoutDashboard,
  Activity,
  Zap,
  CircleDot,
  Timer,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type {
  Match,
  MatchMarket,
  MatchHistoryEntry,
  Selection,
  MarketType,
  HistoryType,
} from '@/lib/types';
import { MARKET_LABELS, MARKET_PRESETS, MARKET_GROUPS, getPreset } from '@/lib/types';
import { useAuth } from '@/context/AuthContext';

function toLocalDatetimeInput(iso: string) {
  const d = new Date(iso);
  const off = d.getTimezoneOffset();
  const local = new Date(d.getTime() - off * 60000);
  return local.toISOString().slice(0, 16);
}

function toLocalDateInput(iso: string) {
  const d = new Date(iso);
  const off = d.getTimezoneOffset();
  const local = new Date(d.getTime() - off * 60000);
  return local.toISOString().slice(0, 10);
}

const inputCls =
  'w-full px-3 py-2.5 rounded-lg bg-slate-900/60 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors text-sm';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function getPresetIcon(icon: string) {
  switch (icon) {
    case 'goal': return Goal;
    case 'flag': return Flag;
    case 'target': return Target;
    case 'trophy': return Trophy;
    case 'card': return Shield;
    default: return Target;
  }
}

// ============================================================
// MAIN ADMIN PAGE
// ============================================================
export default function AdminPage() {
  const { profile } = useAuth();
  const [matches, setMatches] = useState<MatchWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingMatch, setEditingMatch] = useState<Match | null>(null);
  const [showMatchForm, setShowMatchForm] = useState(false);
  const [showBulkForm, setShowBulkForm] = useState(false);
  const [showImportForm, setShowImportForm] = useState(false);
  const [expandedMatch, setExpandedMatch] = useState<string | null>(null);
  const [adminTab, setAdminTab] = useState<'dashboard' | 'matches' | 'users'>('dashboard');
  const [matchSearch, setMatchSearch] = useState('');
  const [matchFilter, setMatchFilter] = useState<'all' | 'upcoming' | 'live' | 'finished'>('all');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [selectedMatchIds, setSelectedMatchIds] = useState<Set<string>>(new Set());
  const [analyzingAll, setAnalyzingAll] = useState(false);
  const [analyzeProgress, setAnalyzeProgress] = useState('');

  interface MatchWithStats extends Match {
    markets_count: number;
    history_count: number;
  }

  async function handleAnalyzeAll() {
    const toAnalyze = matches.filter((m) => m.markets_count === 0);
    if (toAnalyze.length === 0) {
      alert('Todos os jogos já têm mercados cadastrados.');
      return;
    }
    if (!confirm(`Gerar análise automática para ${toAnalyze.length} jogo${toAnalyze.length !== 1 ? 's' : ''} sem mercados? Isso não consome créditos da API.`)) return;
    setAnalyzingAll(true);
    let done = 0;
    for (const m of toAnalyze) {
      setAnalyzeProgress(`${done + 1}/${toAnalyze.length}: ${m.home_team} vs ${m.away_team}`);
      try {
        await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/import-matches?analyze=true&match_id=${m.id}&home=${encodeURIComponent(m.home_team)}&away=${encodeURIComponent(m.away_team)}${m.home_logo ? `&home_logo=${encodeURIComponent(m.home_logo)}` : ''}${m.away_logo ? `&away_logo=${encodeURIComponent(m.away_logo)}` : ''}`, {
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
        });
      } catch {
        // ignore individual failures
      }
      done++;
    }
    setAnalyzingAll(false);
    setAnalyzeProgress('');
    await loadMatches();
  }

  useEffect(() => {
    loadMatches();
  }, []);

  interface UserProfile {
    id: string;
    email: string;
    role: string;
    license_key: string | null;
    key_status: string;
    key_activated_at: string | null;
    created_at: string;
  }

  async function loadUsers() {
    setUsersLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('id, email, role, license_key, key_status, key_activated_at, created_at')
      .order('created_at', { ascending: false });
    if (!error && data) {
      setUsers(data as UserProfile[]);
    }
    setUsersLoading(false);
  }

  async function generateKey(userId: string) {
    const key = generateLicenseKey();
    const { error } = await supabase.rpc('set_license_key', {
      p_user_id: userId,
      p_license_key: key,
      p_status: 'active',
    });
    if (!error) loadUsers();
  }

  async function revokeKey(userId: string) {
    const currentKey = users.find((user) => user.id === userId)?.license_key ?? null;
    const { error } = await supabase.rpc('set_license_key', {
      p_user_id: userId,
      p_license_key: currentKey,
      p_status: 'revoked',
    });
    if (!error) loadUsers();
  }

  async function activateKey(userId: string) {
    const currentKey = users.find((user) => user.id === userId)?.license_key ?? generateLicenseKey();
    const { error } = await supabase.rpc('set_license_key', {
      p_user_id: userId,
      p_license_key: currentKey,
      p_status: 'active',
    });
    if (!error) loadUsers();
  }

  function generateLicenseKey(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let key = '';
    for (let i = 0; i < 4; i++) {
      let part = '';
      for (let j = 0; j < 4; j++) {
        part += chars[Math.floor(Math.random() * chars.length)];
      }
      key += (i > 0 ? '-' : '') + part;
    }
    return key;
  }

  async function loadMatches() {
    setLoading(true);
    const { data, error } = await supabase
      .from('matches')
      .select('*')
      .order('match_date', { ascending: true });

    if (error || !data) {
      setMatches([]);
      setLoading(false);
      return;
    }

    const matchList = data as Match[];

    // Batch-fetch all market and history counts in 2 queries instead of 2 per match
    const [mkRes, histRes] = await Promise.all([
      supabase.from('match_markets').select('match_id'),
      supabase.from('match_history').select('match_id'),
    ]);

    const marketCounts = new Map<string, number>();
    for (const row of (mkRes.data ?? []) as { match_id: string }[]) {
      marketCounts.set(row.match_id, (marketCounts.get(row.match_id) ?? 0) + 1);
    }

    const historyCounts = new Map<string, number>();
    for (const row of (histRes.data ?? []) as { match_id: string }[]) {
      historyCounts.set(row.match_id, (historyCounts.get(row.match_id) ?? 0) + 1);
    }

    const enriched: MatchWithStats[] = matchList.map((m) => ({
      ...m,
      markets_count: marketCounts.get(m.id) ?? 0,
      history_count: historyCounts.get(m.id) ?? 0,
    }));

    setMatches(enriched);
    setLoading(false);
  }

  function handleNewMatch() {
    setEditingMatch(null);
    setShowMatchForm(true);
  }

  function handleEditMatch(m: Match) {
    setEditingMatch(m);
    setShowMatchForm(true);
  }

  async function handleDeleteMatch(id: string) {
    if (!confirm('Tem certeza? O jogo, todos os mercados e histórico serão excluídos permanentemente.')) return;
    await supabase.from('matches').delete().eq('id', id);
    setSelectedMatchIds((current) => {
      const next = new Set(current);
      next.delete(id);
      return next;
    });
    await loadMatches();
  }

  async function handleBulkDelete() {
    const ids = [...selectedMatchIds];
    if (ids.length === 0) return;
    if (!confirm(`Excluir ${ids.length} jogo${ids.length !== 1 ? 's' : ''} e seus dados? Esta ação não pode ser desfeita.`)) return;
    // Delete in batches of 50 to avoid URL length limits
    for (let i = 0; i < ids.length; i += 50) {
      const batch = ids.slice(i, i + 50);
      const { error } = await supabase.from('matches').delete().in('id', batch);
      if (error) {
        alert(`Erro ao excluir (lote ${i / 50 + 1}): ${error.message}`);
        break;
      }
    }
    setSelectedMatchIds(new Set());
    await loadMatches();
  }

  async function handleDeleteAll() {
    if (matches.length === 0) return;
    if (!confirm(`Excluir TODOS os ${matches.length} jogos? Isso apaga todos os mercados e histórico permanentemente. Esta ação NÃO pode ser desfeita.`)) return;
    const allIds = matches.map((m) => m.id);
    for (let i = 0; i < allIds.length; i += 50) {
      const batch = allIds.slice(i, i + 50);
      const { error } = await supabase.from('matches').delete().in('id', batch);
      if (error) {
        alert(`Erro ao excluir (lote ${i / 50 + 1}): ${error.message}`);
        break;
      }
    }
    setSelectedMatchIds(new Set());
    await loadMatches();
  }

  useEffect(() => {
    if (adminTab === 'users' || adminTab === 'dashboard') loadUsers();
  }, [adminTab]);

  const filteredMatches = matches.filter((m) => {
    if (matchFilter !== 'all' && m.status !== matchFilter) return false;
    if (matchSearch) {
      const q = matchSearch.toLowerCase();
      return m.home_team.toLowerCase().includes(q) || m.away_team.toLowerCase().includes(q) || m.league.toLowerCase().includes(q);
    }
    return true;
  });

  const userStats = {
    total: users.length,
    active: users.filter((u) => u.key_status === 'active').length,
    revoked: users.filter((u) => u.key_status === 'revoked').length,
    noKey: users.filter((u) => !u.license_key).length,
  };

  const matchStats = {
    total: matches.length,
    upcoming: matches.filter((m) => m.status === 'upcoming').length,
    live: matches.filter((m) => m.status === 'live').length,
    finished: matches.filter((m) => m.status === 'finished').length,
    markets: matches.reduce((sum, m) => sum + m.markets_count, 0),
    history: matches.reduce((sum, m) => sum + m.history_count, 0),
  };

  if (profile?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
        <div className="text-center">
          <Shield className="w-12 h-12 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400 text-lg">Acesso restrito a administradores.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Header */}
        <div className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 p-6 sm:p-8 mb-6">
          <div className="absolute -top-12 -right-12 w-56 h-56 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-8 left-1/4 w-40 h-40 bg-sky-500/8 rounded-full blur-3xl" />
          <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-5">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3">
                <Shield className="w-3.5 h-3.5" /> Centro de controle <span className="text-sky-300 bg-sky-400/10 border border-sky-400/20 px-1.5 py-0.5 rounded-md">V3</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white">Painel Admin</h1>
              <p className="text-slate-400 text-sm mt-1">Jogos reais, análises, histórico e licenças em um só lugar</p>
              <div className="mt-3 inline-flex items-center gap-2 rounded-lg bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 text-xs font-semibold text-amber-300">
                <Zap className="w-3.5 h-3.5" /> BSD/GoalDir v2 conectada — dados reais protegidos no servidor
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={handleAnalyzeAll}
                disabled={analyzingAll}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 text-white font-semibold hover:bg-amber-400 transition-colors text-sm disabled:opacity-50"
              >
                {analyzingAll ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {analyzingAll ? 'Analisando...' : 'Analisar todos'}
              </button>
              <button onClick={() => setShowImportForm(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-600 text-white font-semibold hover:bg-sky-500 transition-colors text-sm">
                <Download className="w-4 h-4" /> Importar API
              </button>
              <button onClick={() => setShowBulkForm(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-700 text-white font-semibold hover:bg-slate-600 transition-colors text-sm">
                <ListPlus className="w-4 h-4" /> Vários jogos
              </button>
              <button onClick={handleNewMatch} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 transition-colors shadow-lg shadow-emerald-500/20 text-sm">
                <Plus className="w-4 h-4" /> Novo Jogo
              </button>
            </div>
          </div>
        </div>

        {/* Analyze Progress */}
        {analyzingAll && (
          <div className="mb-6 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-4 flex items-center gap-3">
            <Loader2 className="w-5 h-5 text-amber-400 animate-spin flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-300">Gerando análises...</p>
              <p className="text-xs text-amber-400/70">{analyzeProgress}</p>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 p-1.5 rounded-2xl bg-slate-900/60 border border-slate-800 overflow-x-auto">
          {([
            ['dashboard', 'Dashboard', LayoutDashboard],
            ['matches', 'Jogos', Trophy],
            ['users', 'Usuários & Keys', Users],
          ] as const).map(([key, label, Icon]) => (
            <button
              key={key}
              onClick={() => setAdminTab(key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all whitespace-nowrap flex-1 justify-center ${
                adminTab === key
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {adminTab === 'dashboard' ? (
          <div className="space-y-6">
            {/* Metric Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 to-emerald-950/30 p-5">
                <div className="absolute top-3 right-3 w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center"><Trophy className="w-5 h-5 text-emerald-400" /></div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Total de jogos</p>
                <p className="text-3xl font-bold text-white mt-2">{matchStats.total}</p>
              </div>
              <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 to-sky-950/30 p-5">
                <div className="absolute top-3 right-3 w-10 h-10 rounded-xl bg-sky-500/10 flex items-center justify-center"><BarChart3 className="w-5 h-5 text-sky-400" /></div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Mercados</p>
                <p className="text-3xl font-bold text-white mt-2">{matchStats.markets}</p>
              </div>
              <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 to-amber-950/30 p-5">
                <div className="absolute top-3 right-3 w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center"><Users className="w-5 h-5 text-amber-400" /></div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Usuários</p>
                <p className="text-3xl font-bold text-white mt-2">{userStats.total}</p>
              </div>
              <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 to-teal-950/30 p-5">
                <div className="absolute top-3 right-3 w-10 h-10 rounded-xl bg-teal-500/10 flex items-center justify-center"><KeyRound className="w-5 h-5 text-teal-400" /></div>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Keys ativas</p>
                <p className="text-3xl font-bold text-white mt-2">{userStats.active}</p>
              </div>
            </div>

            {/* Status Breakdown */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4"><Activity className="w-4 h-4 text-emerald-400" /> Status dos jogos</h3>
              <div className="flex h-3 rounded-full overflow-hidden bg-slate-800">
                {matchStats.total > 0 && (<>
                  <div className="bg-emerald-500 transition-all duration-500" style={{ width: `${(matchStats.upcoming / matchStats.total) * 100}%` }} />
                  <div className="bg-red-500 transition-all duration-500" style={{ width: `${(matchStats.live / matchStats.total) * 100}%` }} />
                  <div className="bg-slate-500 transition-all duration-500" style={{ width: `${(matchStats.finished / matchStats.total) * 100}%` }} />
                </>)}
              </div>
              <div className="flex flex-wrap gap-4 mt-3 text-xs">
                <span className="flex items-center gap-1.5 text-emerald-400"><CircleDot className="w-3 h-3" /> Em breve: <strong>{matchStats.upcoming}</strong></span>
                <span className="flex items-center gap-1.5 text-red-400"><Zap className="w-3 h-3" /> Ao vivo: <strong>{matchStats.live}</strong></span>
                <span className="flex items-center gap-1.5 text-slate-400"><Timer className="w-3 h-3" /> Encerrados: <strong>{matchStats.finished}</strong></span>
              </div>
            </div>

            {/* Recent Matches + License Stats */}
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2"><Trophy className="w-4 h-4 text-emerald-400" /> Jogos recentes</h3>
                  <button onClick={() => setAdminTab('matches')} className="text-xs text-emerald-400 hover:text-emerald-300 font-medium">Ver todos</button>
                </div>
                <div className="space-y-1">
                  {matches.slice(0, 6).map((m) => (
                    <div key={m.id} className="flex items-center justify-between text-sm py-2.5 border-b border-slate-800 last:border-0">
                      <div className="min-w-0 flex-1">
                        <p className="text-slate-300 truncate">{m.home_team} <span className="text-slate-600">vs</span> {m.away_team}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{m.league}</p>
                      </div>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0 ml-3 ${
                        m.status === 'live' ? 'text-red-400 bg-red-400/10' :
                        m.status === 'finished' ? 'text-slate-400 bg-slate-700/30' :
                        'text-emerald-400 bg-emerald-400/10'
                      }`}>{m.status === 'live' ? 'Ao vivo' : m.status === 'finished' ? 'Encerrado' : 'Em breve'}</span>
                    </div>
                  ))}
                  {matches.length === 0 && <p className="text-slate-500 text-sm py-4 text-center">Nenhum jogo cadastrado.</p>}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2"><KeyRound className="w-4 h-4 text-amber-400" /> Licenças</h3>
                  <button onClick={() => setAdminTab('users')} className="text-xs text-emerald-400 hover:text-emerald-300 font-medium">Gerenciar</button>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                    <span className="text-sm text-slate-400 flex items-center gap-2"><KeyRound className="w-3.5 h-3.5 text-emerald-400" /> Keys ativas</span>
                    <span className="text-xl font-bold text-emerald-400">{userStats.active}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-red-500/5 border border-red-500/10">
                    <span className="text-sm text-slate-400 flex items-center gap-2"><UserX className="w-3.5 h-3.5 text-red-400" /> Keys revogadas</span>
                    <span className="text-xl font-bold text-red-400">{userStats.revoked}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-700/20 border border-slate-700/30">
                    <span className="text-sm text-slate-400 flex items-center gap-2"><UserCheck className="w-3.5 h-3.5 text-slate-400" /> Sem key</span>
                    <span className="text-xl font-bold text-slate-400">{userStats.noKey}</span>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                    <span className="text-sm text-slate-400">Total de usuários</span>
                    <span className="text-xl font-bold text-white">{userStats.total}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* League Distribution + Unanalyzed */}
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4"><BarChart3 className="w-4 h-4 text-sky-400" /> Jogos por campeonato</h3>
                <div className="space-y-2">
                  {Object.entries(
                    matches.reduce((acc, m) => {
                      acc[m.league] = (acc[m.league] ?? 0) + 1;
                      return acc;
                    }, {} as Record<string, number>)
                  ).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([league, count]) => (
                    <div key={league} className="flex items-center gap-3">
                      <span className="text-xs text-slate-400 w-32 truncate">{league}</span>
                      <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-emerald-500 to-sky-500 rounded-full transition-all duration-500" style={{ width: `${(count / matches.length) * 100}%` }} />
                      </div>
                      <span className="text-xs font-bold text-white w-8 text-right">{count}</span>
                    </div>
                  ))}
                  {matches.length === 0 && <p className="text-slate-500 text-sm py-4 text-center">Nenhum dado.</p>}
                </div>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2"><Sparkles className="w-4 h-4 text-amber-400" /> Sem análise</h3>
                  {matches.filter((m) => m.markets_count === 0).length > 0 && (
                    <button onClick={handleAnalyzeAll} disabled={analyzingAll} className="text-xs text-amber-400 hover:text-amber-300 font-medium disabled:opacity-50">
                      Analisar todos
                    </button>
                  )}
                </div>
                <div className="space-y-1">
                  {matches.filter((m) => m.markets_count === 0).slice(0, 6).map((m) => (
                    <div key={m.id} className="flex items-center justify-between text-sm py-2 border-b border-slate-800 last:border-0">
                      <p className="text-slate-300 truncate">{m.home_team} vs {m.away_team}</p>
                      <span className="text-xs text-amber-400 flex-shrink-0 ml-2">Sem mercados</span>
                    </div>
                  ))}
                  {matches.filter((m) => m.markets_count === 0).length === 0 && (
                    <p className="text-emerald-400 text-sm py-4 text-center flex items-center justify-center gap-2">
                      <CheckCircle className="w-4 h-4" /> Todos os jogos têm análise!
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : adminTab === 'users' ? (
          <div className="space-y-4">
            {/* User Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><Users className="w-3.5 h-3.5" /> Total</div>
                <p className="text-2xl font-bold text-white">{userStats.total}</p>
              </div>
              <div className="rounded-2xl border border-emerald-800/50 bg-emerald-950/20 p-4">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-medium uppercase tracking-wide mb-1"><KeyRound className="w-3.5 h-3.5" /> Ativas</div>
                <p className="text-2xl font-bold text-emerald-400">{userStats.active}</p>
              </div>
              <div className="rounded-2xl border border-red-800/50 bg-red-950/20 p-4">
                <div className="flex items-center gap-2 text-red-400 text-xs font-medium uppercase tracking-wide mb-1"><UserX className="w-3.5 h-3.5" /> Revogadas</div>
                <p className="text-2xl font-bold text-red-400">{userStats.revoked}</p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><UserCheck className="w-3.5 h-3.5" /> Sem key</div>
                <p className="text-2xl font-bold text-slate-400">{userStats.noKey}</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-sm text-slate-400">
                {users.length} usuário{users.length !== 1 ? 's' : ''} cadastrado{users.length !== 1 ? 's' : ''}
              </p>
              <div className="relative w-full sm:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder="Buscar por ID ou e-mail" className={`${inputCls} pl-9`} />
              </div>
              <button
                onClick={loadUsers}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-700 text-white text-sm font-medium hover:bg-slate-600"
              >
                <RefreshCw className="w-4 h-4" />
                Atualizar
              </button>
            </div>

            {usersLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
              </div>
            ) : users.length === 0 ? (
              <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-12 text-center">
                <Users className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">Nenhum usuário cadastrado.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {users.filter((u) => {
                  const query = userSearch.trim().toLowerCase();
                  return !query || u.id.toLowerCase().includes(query) || u.email.toLowerCase().includes(query);
                }).map((u) => (
                  <div key={u.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 p-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <span className="text-white font-medium truncate">{u.email}</span>
                          {u.role === 'admin' && (
                            <span className="text-xs font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full">ADMIN</span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-1 font-mono">
                          ID: {u.id}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Criado em {new Date(u.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        {u.license_key ? (
                          <div className="flex items-center gap-2">
                            <span className={`text-xs font-bold px-2 py-1 rounded-lg ${
                              u.key_status === 'active' ? 'text-emerald-400 bg-emerald-400/10' :
                              u.key_status === 'revoked' ? 'text-red-400 bg-red-400/10' :
                              'text-slate-400 bg-slate-700/30'
                            }`}>
                              {u.key_status === 'active' ? 'ATIVA' : u.key_status === 'revoked' ? 'REVOGADA' : 'INATIVA'}
                            </span>
                            <span className="font-mono text-sm text-slate-300 bg-slate-900/60 px-2 py-1 rounded-lg">
                              {u.license_key}
                            </span>
                            <button
                              onClick={() => navigator.clipboard?.writeText(u.license_key || '')}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
                              title="Copiar key"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-500">Sem key</span>
                        )}

                        <div className="flex gap-2">
                          {!u.license_key && (
                            <button
                              onClick={() => generateKey(u.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 text-white text-xs font-semibold hover:bg-emerald-600"
                            >
                              <KeyRound className="w-3.5 h-3.5" />
                              Gerar Key
                            </button>
                          )}
                          {u.license_key && u.key_status !== 'active' && (
                            <button
                              onClick={() => activateKey(u.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 text-white text-xs font-semibold hover:bg-emerald-600"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              Ativar
                            </button>
                          )}
                          {u.license_key && u.key_status === 'active' && (
                            <button
                              onClick={() => revokeKey(u.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/30"
                            >
                              <UserX className="w-3.5 h-3.5" />
                              Revogar
                            </button>
                          )}
                          {u.license_key && (
                            <button
                              onClick={() => generateKey(u.id)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-700 text-white text-xs font-semibold hover:bg-slate-600"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              Renovar
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
        <>

        {/* Search + Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input value={matchSearch} onChange={(e) => setMatchSearch(e.target.value)} placeholder="Buscar por time ou campeonato..." className={`${inputCls} pl-9`} />
          </div>
          <div className="flex gap-1 bg-slate-900/60 rounded-xl p-1 border border-slate-800 overflow-x-auto">
            {([
              ['all', 'Todos'],
              ['upcoming', 'Em breve'],
              ['live', 'Ao vivo'],
              ['finished', 'Encerrados'],
            ] as const).map(([key, label]) => (
              <button key={key} onClick={() => setMatchFilter(key)} className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${matchFilter === key ? 'bg-emerald-500 text-white' : 'text-slate-400 hover:text-white'}`}>{label}</button>
            ))}
          </div>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><Trophy className="w-3.5 h-3.5" /> Jogos</div>
            <p className="text-2xl font-bold text-white">{matchStats.total}</p>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><BarChart3 className="w-3.5 h-3.5" /> Mercados</div>
            <p className="text-2xl font-bold text-white">{matchStats.markets}</p>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><TrendingUp className="w-3.5 h-3.5" /> Histórico</div>
            <p className="text-2xl font-bold text-white">{matchStats.history}</p>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium uppercase tracking-wide mb-1"><Zap className="w-3.5 h-3.5" /> Ao vivo</div>
            <p className="text-2xl font-bold text-white">{matchStats.live}</p>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : filteredMatches.length === 0 ? (
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-12 text-center">
            <Trophy className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">{matches.length === 0 ? 'Nenhum jogo cadastrado ainda.' : 'Nenhum jogo encontrado na busca.'}</p>
            <p className="text-slate-500 text-sm mt-1">{matches.length === 0 ? 'Clique em "Novo Jogo" para começar.' : 'Tente outro termo ou filtro.'}</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-3">
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input type="checkbox" checked={filteredMatches.length > 0 && selectedMatchIds.size === filteredMatches.length} onChange={() => setSelectedMatchIds(selectedMatchIds.size === filteredMatches.length ? new Set() : new Set(filteredMatches.map((m) => m.id)))} className="w-4 h-4 rounded accent-emerald-500" />
                Selecionar todos os {filteredMatches.length} jogos
              </label>
              <div className="flex gap-2">
                <button onClick={handleDeleteAll} className="flex items-center justify-center gap-2 rounded-xl bg-red-500/15 px-4 py-2 text-sm font-bold text-red-300 hover:bg-red-500/25 transition-colors"><Trash2 className="w-4 h-4" /> Excluir TODOS ({matches.length})</button>
                <button onClick={handleBulkDelete} disabled={selectedMatchIds.size === 0} className="flex items-center justify-center gap-2 rounded-xl bg-amber-500/15 px-4 py-2 text-sm font-bold text-amber-300 hover:bg-amber-500/25 disabled:cursor-not-allowed disabled:opacity-40"><Trash2Icon className="w-4 h-4" /> Excluir selecionados {selectedMatchIds.size > 0 ? `(${selectedMatchIds.size})` : ''}</button>
              </div>
            </div>
            {filteredMatches.map((m) => (
              <MatchRow
                key={m.id}
                match={m}
                expanded={expandedMatch === m.id}
                selected={selectedMatchIds.has(m.id)}
                onSelect={() => setSelectedMatchIds((current) => {
                  const next = new Set(current);
                  if (next.has(m.id)) next.delete(m.id); else next.add(m.id);
                  return next;
                })}
                onToggle={() =>
                  setExpandedMatch(expandedMatch === m.id ? null : m.id)
                }
                onEdit={() => handleEditMatch(m)}
                onDelete={() => handleDeleteMatch(m.id)}
                onRefresh={loadMatches}
              />
            ))}
          </div>
        )}
        </>
        )}

      </div>

      {showMatchForm && (
        <MatchFormModal
          match={editingMatch}
          onClose={() => setShowMatchForm(false)}
          onSaved={() => {
            setShowMatchForm(false);
            loadMatches();
          }}
        />
      )}

      {showBulkForm && (
        <BulkMatchFormModal
          onClose={() => setShowBulkForm(false)}
          onSaved={() => {
            setShowBulkForm(false);
            loadMatches();
          }}
        />
      )}

      {showImportForm && (
        <ImportMatchesModal
          onClose={() => setShowImportForm(false)}
          onSaved={() => {
            setShowImportForm(false);
            loadMatches();
          }}
        />
      )}
    </div>
  );
}

// ============================================================
// BULK MATCH FORM — add multiple matches at once
// ============================================================
interface BulkRow {
  home_team: string;
  away_team: string;
  league: string;
  match_date: string;
  status: string;
  home_logo: string;
  away_logo: string;
}

function BulkMatchFormModal({
  onClose,
  onSaved,
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const defaultDate = toLocalDatetimeInput(new Date(Date.now() + 86400000).toISOString());
  const [rows, setRows] = useState<BulkRow[]>([
    { home_team: '', away_team: '', league: 'Brasileirão', match_date: defaultDate, status: 'upcoming', home_logo: '', away_logo: '' },
  ]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function updateRow(idx: number, field: keyof BulkRow, value: string) {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r)));
  }

  function addRow() {
    setRows((prev) => [...prev, { home_team: '', away_team: '', league: prev[prev.length - 1]?.league ?? 'Brasileirão', match_date: prev[prev.length - 1]?.match_date ?? defaultDate, status: 'upcoming', home_logo: '', away_logo: '' }]);
  }

  function removeRow(idx: number) {
    setRows((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSave() {
    const valid = rows.filter((r) => r.home_team.trim() && r.away_team.trim() && r.match_date);
    if (valid.length === 0) {
      setError('Preencha pelo menos um jogo com time da casa, visitante e data.');
      return;
    }

    setSaving(true);
    setError(null);

    const payload = valid.map((r) => ({
      home_team: r.home_team.trim(),
      away_team: r.away_team.trim(),
      league: r.league.trim() || 'Brasileirão',
      match_date: new Date(r.match_date).toISOString(),
      status: r.status,
      home_logo: r.home_logo || null,
      away_logo: r.away_logo || null,
      best_market: '',
      best_pick: '',
      best_pick_odds: 0,
      best_pick_probability: 0,
      analysis_summary: '',
    }));

    const { error: insertError } = await supabase.from('matches').insert(payload);

    if (insertError) {
      setError(insertError.message);
      setSaving(false);
      return;
    }
    setSaving(false);
    onSaved();
  }

  const validCount = rows.filter((r) => r.home_team.trim() && r.away_team.trim() && r.match_date).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700 sticky top-0 bg-slate-800 z-10">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ListPlus className="w-5 h-5 text-emerald-400" />
              Adicionar vários jogos
            </h2>
            <p className="text-sm text-slate-400 mt-0.5">
              Preencha os times, data e logo. Clique em + para adicionar mais linhas.
            </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Column headers */}
          <div className="hidden lg:grid grid-cols-[1fr_1fr_1fr_180px_120px_1fr_1fr_40px] gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wide px-1">
            <span>Time Casa</span>
            <span>Visitante</span>
            <span>Campeonato</span>
            <span>Data e Hora</span>
            <span>Status</span>
            <span>Logo Casa (URL)</span>
            <span>Logo Visitante (URL)</span>
            <span></span>
          </div>

          {rows.map((row, idx) => (
            <div key={idx} className="grid grid-cols-1 lg:grid-cols-[1fr_1fr_1fr_180px_120px_1fr_1fr_40px] gap-2 items-start bg-slate-900/40 p-2 rounded-lg">
              <input
                placeholder="Time da casa"
                value={row.home_team}
                onChange={(e) => updateRow(idx, 'home_team', e.target.value)}
                className={inputCls}
              />
              <input
                placeholder="Visitante"
                value={row.away_team}
                onChange={(e) => updateRow(idx, 'away_team', e.target.value)}
                className={inputCls}
              />
              <input
                placeholder="Campeonato"
                value={row.league}
                onChange={(e) => updateRow(idx, 'league', e.target.value)}
                className={inputCls}
              />
              <input
                type="datetime-local"
                value={row.match_date}
                onChange={(e) => updateRow(idx, 'match_date', e.target.value)}
                className={inputCls}
              />
              <select
                value={row.status}
                onChange={(e) => updateRow(idx, 'status', e.target.value)}
                className={inputCls}
              >
                <option value="upcoming">Em breve</option>
                <option value="live">Ao vivo</option>
                <option value="finished">Encerrado</option>
              </select>
              <input
                placeholder="https://..."
                value={row.home_logo}
                onChange={(e) => updateRow(idx, 'home_logo', e.target.value)}
                className={inputCls}
              />
              <input
                placeholder="https://..."
                value={row.away_logo}
                onChange={(e) => updateRow(idx, 'away_logo', e.target.value)}
                className={inputCls}
              />
              <button
                type="button"
                onClick={() => removeRow(idx)}
                disabled={rows.length === 1}
                className="p-2.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                title="Remover linha"
              >
                <Trash2Icon className="w-4 h-4" />
              </button>
            </div>
          ))}

          <button
            type="button"
            onClick={addRow}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors w-full justify-center border border-dashed border-slate-600"
          >
            <Plus className="w-5 h-5" />
            Adicionar mais uma linha
          </button>

          <div className="flex items-center justify-between pt-4 border-t border-slate-700">
            <p className="text-sm text-slate-400">
              {validCount} jogo{validCount !== 1 ? 's' : ''} pronto{validCount !== 1 ? 's' : ''} para salvar
            </p>
            <div className="flex gap-3">
              <button type="button" onClick={onClose} className="px-5 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors">
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saving || validCount === 0}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                Salvar {validCount > 0 ? `(${validCount})` : ''}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Match Row — shows stats inline, expandable for full editing
// ============================================================
function MatchRow({
  match,
  expanded,
  onToggle,
  selected,
  onSelect,
  onEdit,
  onDelete,
  onRefresh,
}: {
  match: Match & { markets_count: number; history_count: number };
  expanded: boolean;
  selected: boolean;
  onSelect: () => void;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onRefresh: () => void;
}) {
  const [analyzing, setAnalyzing] = useState(false);

  async function handleAnalyze() {
    setAnalyzing(true);
    try {
      await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/import-matches?analyze=true&match_id=${match.id}&home=${encodeURIComponent(match.home_team)}&away=${encodeURIComponent(match.away_team)}${match.home_logo ? `&home_logo=${encodeURIComponent(match.home_logo)}` : ''}${match.away_logo ? `&away_logo=${encodeURIComponent(match.away_logo)}` : ''}`, {
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
      });
      onRefresh();
    } catch {
      // ignore
    }
    setAnalyzing(false);
  }

  return (
    <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden transition-all">
      {/* Collapsed header */}
      <div className="flex items-center gap-3 p-4">
        <input type="checkbox" checked={selected} onChange={onSelect} className="w-4 h-4 rounded accent-emerald-500" aria-label={`Selecionar ${match.home_team} x ${match.away_team}`} />
        <button
          onClick={onToggle}
          className="text-slate-400 hover:text-white transition-colors flex-shrink-0"
        >
          {expanded ? (
            <ChevronDown className="w-5 h-5" />
          ) : (
            <ChevronRight className="w-5 h-5" />
          )}
        </button>

        <div className="flex-1 min-w-0">
          <p className="text-white font-medium truncate text-sm sm:text-base">
            {match.home_team} <span className="text-slate-500">vs</span> {match.away_team}
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 flex-wrap">
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {new Date(match.match_date).toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
            <span className="text-slate-600">•</span>
            <span>{match.league}</span>
          </div>
        </div>

        {/* Inline stats badges */}
        <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
          <span
            className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg ${
              match.markets_count > 0
                ? 'text-emerald-400 bg-emerald-400/10'
                : 'text-slate-500 bg-slate-700/30'
            }`}
          >
            <BarChart3 className="w-3 h-3" />
            {match.markets_count} mercados
          </span>
          <span
            className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg ${
              match.history_count > 0
                ? 'text-blue-400 bg-blue-400/10'
                : 'text-slate-500 bg-slate-700/30'
            }`}
          >
            <TrendingUp className="w-3 h-3" />
            {match.history_count} jogos
          </span>
        </div>

        {match.best_market && (
          <span className="hidden md:inline-flex items-center gap-1 text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-lg flex-shrink-0">
            <Star className="w-3 h-3" /> {match.best_market}
          </span>
        )}

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-sky-400 bg-sky-400/10 hover:bg-sky-400/20 transition-colors flex-shrink-0 disabled:opacity-50"
          title="Gerar análise automática"
        >
          {analyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
          <span className="hidden lg:inline">{analyzing ? 'Analisando...' : 'Analisar'}</span>
        </button>

        <button
          onClick={onToggle}
          className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-emerald-400 bg-emerald-400/10 hover:bg-emerald-400/20 transition-colors flex-shrink-0"
          title="Abrir edição de mercados e histórico"
        >
          <BarChart3 className="w-3.5 h-3.5" />
          Mercados + histórico
        </button>

        <button
          onClick={onEdit}
          className="p-2 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-700 transition-colors flex-shrink-0"
          title="Editar jogo"
        >
          <Pencil className="w-4 h-4" />
        </button>
        <button
          onClick={onDelete}
          className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-700 transition-colors flex-shrink-0"
          title="Excluir jogo"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Mobile stats */}
      <div className="sm:hidden flex items-center gap-2 px-4 pb-3">
        <span
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg ${
            match.markets_count > 0
              ? 'text-emerald-400 bg-emerald-400/10'
              : 'text-slate-500 bg-slate-700/30'
          }`}
        >
          <BarChart3 className="w-3 h-3" />
          {match.markets_count} mercados
        </span>
        <span
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg ${
            match.history_count > 0
              ? 'text-blue-400 bg-blue-400/10'
              : 'text-slate-500 bg-slate-700/30'
          }`}
        >
          <TrendingUp className="w-3 h-3" />
          {match.history_count} jogos
        </span>
      </div>

      {/* Expanded content */}
      {expanded && (
        <div className="border-t border-slate-700 bg-slate-900/40">
          {/* Quick warning if no data */}
          {match.markets_count === 0 && match.history_count === 0 && (
            <div className="px-4 py-3 bg-amber-500/5 border-b border-amber-500/10">
              <p className="text-amber-400/80 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Este jogo ainda não tem mercados nem histórico cadastrados. Use os botões abaixo.
              </p>
            </div>
          )}

          <div className="p-4 space-y-6">
            <MarketsEditor
              matchId={match.id}
              homeTeam={match.home_team}
              awayTeam={match.away_team}
              onRefresh={onRefresh}
            />
            <HistoryEditor
              matchId={match.id}
              homeTeam={match.home_team}
              awayTeam={match.away_team}
              onRefresh={onRefresh}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// MATCH FORM MODAL (create/edit match + best market picker)
// ============================================================
function MatchFormModal({
  match,
  onClose,
  onSaved,
}: {
  match: Match | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    home_team: match?.home_team ?? '',
    away_team: match?.away_team ?? '',
    league: match?.league ?? 'Brasileirão',
    match_date: match
      ? toLocalDatetimeInput(match.match_date)
      : toLocalDatetimeInput(new Date(Date.now() + 86400000).toISOString()),
    status: match?.status ?? 'upcoming',
    home_logo: match?.home_logo ?? '',
    away_logo: match?.away_logo ?? '',
    best_market: match?.best_market ?? '',
    best_pick: match?.best_pick ?? '',
    best_pick_odds: match?.best_pick_odds ?? 0,
    best_pick_probability: match?.best_pick_probability ?? 0,
    analysis_summary: match?.analysis_summary ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      ...form,
      match_date: new Date(form.match_date).toISOString(),
      best_pick_odds: Number(form.best_pick_odds),
      best_pick_probability: Number(form.best_pick_probability),
    };

    let result;
    if (match) {
      result = await supabase.from('matches').update(payload).eq('id', match.id);
    } else {
      result = await supabase.from('matches').insert(payload);
    }

    if (result.error) {
      setError(result.error.message);
      setSaving(false);
      return;
    }
    setSaving(false);
    onSaved();
  }

  function update(field: string, value: string | number) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  const bestMarketOptions = MARKET_PRESETS.map((p) => p.label);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700 sticky top-0 bg-slate-800 z-10">
          <h2 className="text-xl font-bold text-white">
            {match ? 'Editar Jogo' : 'Novo Jogo'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Time da Casa">
              <input required value={form.home_team} onChange={(e) => update('home_team', e.target.value)} className={inputCls} />
            </Field>
            <Field label="Time Visitante">
              <input required value={form.away_team} onChange={(e) => update('away_team', e.target.value)} className={inputCls} />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Campeonato">
              <input value={form.league} onChange={(e) => update('league', e.target.value)} className={inputCls} />
            </Field>
            <Field label="Data e Hora">
              <input type="datetime-local" required value={form.match_date} onChange={(e) => update('match_date', e.target.value)} className={inputCls} />
            </Field>
          </div>

          <div className="grid sm:grid-cols-3 gap-4">
            <Field label="Status">
              <select value={form.status} onChange={(e) => update('status', e.target.value)} className={inputCls}>
                <option value="upcoming">Em breve</option>
                <option value="live">Ao vivo</option>
                <option value="finished">Encerrado</option>
              </select>
            </Field>
            <Field label="Logo Casa (URL da foto)">
              <input value={form.home_logo} onChange={(e) => update('home_logo', e.target.value)} className={inputCls} placeholder="https://..." />
            </Field>
            <Field label="Logo Visitante (URL da foto)">
              <input value={form.away_logo} onChange={(e) => update('away_logo', e.target.value)} className={inputCls} placeholder="https://..." />
            </Field>
          </div>

          {(form.home_logo || form.away_logo) && (
            <div className="flex items-center gap-4 p-3 rounded-lg bg-slate-900/40 border border-slate-700">
              {form.home_logo && (form.home_logo.startsWith('http') || form.home_logo.startsWith('/')) && (
                <img src={form.home_logo} alt="" className="w-12 h-12 rounded-xl object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
              )}
              {form.away_logo && (form.away_logo.startsWith('http') || form.away_logo.startsWith('/')) && (
                <img src={form.away_logo} alt="" className="w-12 h-12 rounded-xl object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
              )}
            </div>
          )}

          <div className="pt-4 border-t border-slate-700">
            <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-1.5">
              <Star className="w-4 h-4" />
              MELHOR MERCADO (destaque do jogo)
            </h3>
            <div className="space-y-4">
              <Field label="Escolher Mercado">
                <select value={form.best_market} onChange={(e) => update('best_market', e.target.value)} className={inputCls}>
                  <option value="">— Selecione o melhor mercado —</option>
                  {bestMarketOptions.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </Field>
              <Field label="Pick (recomendação)">
                <input value={form.best_pick} onChange={(e) => update('best_pick', e.target.value)} placeholder="Ex: Acima 2.5 gols" className={inputCls} />
              </Field>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Odd">
                  <input type="number" step="0.01" value={form.best_pick_odds} onChange={(e) => update('best_pick_odds', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Probabilidade (%)">
                  <input type="number" step="1" value={form.best_pick_probability} onChange={(e) => update('best_pick_probability', e.target.value)} className={inputCls} />
                </Field>
              </div>
              <Field label="Resumo da Análise">
                <textarea value={form.analysis_summary} onChange={(e) => update('analysis_summary', e.target.value)} rows={3} className={inputCls} />
              </Field>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 disabled:opacity-50 transition-colors flex items-center justify-center gap-2">
              {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================================
// MARKETS EDITOR — grid of all presets, inline create/edit
// ============================================================
function MarketsEditor({
  matchId,
  homeTeam,
  awayTeam,
  onRefresh,
}: {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  onRefresh: () => void;
}) {
  const [markets, setMarkets] = useState<MatchMarket[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingMarket, setEditingMarket] = useState<MatchMarket | null>(null);
  const [presetKey, setPresetKey] = useState<MarketType | null>(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadMarkets();
  }, [matchId]);

  async function loadMarkets() {
    setLoading(true);
    const { data } = await supabase
      .from('match_markets')
      .select('*')
      .eq('match_id', matchId);
    setMarkets((data as MatchMarket[]) ?? []);
    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('Excluir este mercado?')) return;
    await supabase.from('match_markets').delete().eq('id', id);
    loadMarkets();
    onRefresh();
  }

  function openNewMarket(key: MarketType) {
    setPresetKey(key);
    setEditingMarket(null);
    setShowForm(true);
  }

  function openEditMarket(mk: MatchMarket) {
    setEditingMarket(mk);
    setPresetKey(null);
    setShowForm(true);
  }

  const createdTypes = new Set(markets.map((m) => m.market_type));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-emerald-400" />
          Mercados de Apostas
          <span className="text-slate-500 font-normal">({markets.length}/{MARKET_PRESETS.length})</span>
        </h4>
      </div>

      {loading ? (
        <Loader2 className="w-5 h-5 text-slate-500 animate-spin" />
      ) : (
        <div className="space-y-4">
          {/* Created markets — show inline with their data */}
          {markets.length > 0 && (
            <div className="space-y-2">
              {markets.map((mk) => {
                const preset = getPreset(mk.market_type);
                const Icon = preset ? getPresetIcon(preset.icon) : Target;
                const topPick = mk.selections?.reduce((best, s) =>
                  s.probability > best.probability ? s : best, mk.selections[0] ?? { label: '', odds: 0, probability: 0 });
                return (
                  <div key={mk.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/60 border border-slate-700 hover:border-slate-600 transition-colors">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white font-medium">
                        {MARKET_LABELS[mk.market_type]}
                      </p>
                      {topPick && topPick.probability > 0 && (
                        <p className="text-xs text-slate-400 mt-0.5">
                          Top: <span className="text-emerald-400 font-medium">{topPick.label}</span> — {topPick.probability}% (odd {topPick.odds})
                        </p>
                      )}
                      {(!topPick || topPick.probability === 0) && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          {mk.selections?.length ?? 0} seleções — clique para preencher
                        </p>
                      )}
                    </div>
                    <button onClick={() => openEditMarket(mk)} className="p-1.5 rounded text-slate-400 hover:text-emerald-400 transition-colors" title="Editar mercado">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(mk.id)} className="p-1.5 rounded text-slate-400 hover:text-red-400 transition-colors" title="Excluir mercado">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* Available presets grid */}
          <div>
            <p className="text-xs text-slate-500 mb-3 font-medium flex items-center gap-1">
              <Plus className="w-3.5 h-3.5" />
              Clique para cadastrar um mercado:
            </p>
            <div className="space-y-3">
              {MARKET_GROUPS.map((grp) => (
                <div key={grp.group}>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2">
                    {grp.group}
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {grp.items.map((item) => {
                      const Icon = getPresetIcon(item.icon);
                      const exists = createdTypes.has(item.key);
                      return (
                        <button
                          key={item.key}
                          onClick={() => openNewMarket(item.key)}
                          disabled={exists}
                          className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                            exists
                              ? 'bg-slate-800/30 text-slate-600 cursor-not-allowed border border-slate-800'
                              : 'bg-slate-800 text-slate-300 hover:bg-emerald-500/10 hover:text-emerald-400 hover:border-emerald-500/30 border border-slate-700'
                          }`}
                        >
                          <Icon className="w-4 h-4 flex-shrink-0" />
                          <span className="truncate">{item.label}</span>
                          {exists && <Check className="w-3.5 h-3.5 ml-auto text-emerald-500" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <MarketFormModal
          matchId={matchId}
          market={editingMarket}
          presetKey={presetKey}
          homeTeam={homeTeam}
          awayTeam={awayTeam}
          onClose={() => setShowForm(false)}
          onSaved={() => {
            setShowForm(false);
            loadMarkets();
            onRefresh();
          }}
        />
      )}
    </div>
  );
}

// ============================================================
// MARKET FORM MODAL — auto-fills selections from preset
// ============================================================
function MarketFormModal({
  matchId,
  market,
  presetKey,
  homeTeam,
  awayTeam,
  onClose,
  onSaved,
}: {
  matchId: string;
  market: MatchMarket | null;
  presetKey: MarketType | null;
  homeTeam: string;
  awayTeam: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const preset = presetKey ? getPreset(presetKey) : undefined;

  const [marketType] = useState<MarketType>(
    market?.market_type ?? presetKey ?? 'goals_2.5'
  );
  const [selections, setSelections] = useState<Selection[]>(
    market?.selections ?? customizeSelections(preset?.selections ?? [], homeTeam, awayTeam, presetKey)
  );
  const [recommendation, setRecommendation] = useState(market?.recommendation ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function customizeSelections(base: Selection[], home: string, away: string, key: MarketType | null): Selection[] {
    if (key === 'result') {
      return base.map((s) => ({
        ...s,
        label: s.label.replace('Casa', home || 'Casa').replace('Visitante', away || 'Visitante'),
      }));
    }
    return base.map((s) => ({ ...s }));
  }

  function updateSelection(idx: number, field: keyof Selection, value: string | number) {
    setSelections((prev) =>
      prev.map((s, i) =>
        i === idx ? { ...s, [field]: field === 'label' ? value : Number(value) } : s
      )
    );
  }

  function addSelection() {
    setSelections((prev) => [...prev, { label: '', odds: 0, probability: 0 }]);
  }

  function removeSelection(idx: number) {
    setSelections((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const lineVal = marketType.includes('_') ? marketType.split('_')[1] : '';
    const payload = {
      match_id: matchId,
      market_type: marketType,
      line: lineVal,
      selections: selections as unknown as Record<string, unknown>[],
      recommendation,
    };

    let result;
    if (market) {
      result = await supabase.from('match_markets').update(payload).eq('id', market.id);
    } else {
      result = await supabase.from('match_markets').insert(payload);
    }

    if (result.error) {
      setError(result.error.message);
      setSaving(false);
      return;
    }
    setSaving(false);
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700 sticky top-0 bg-slate-800 z-10">
          <div>
            <h2 className="text-lg font-bold text-white">
              {market ? 'Editar' : 'Novo'} Mercado
            </h2>
            <p className="text-sm text-emerald-400 mt-0.5">{MARKET_LABELS[marketType]}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-slate-300">
                Seleções — Odd + Probabilidade (%)
              </label>
              <button type="button" onClick={addSelection} className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300">
                <Plus className="w-3.5 h-3.5" /> Adicionar
              </button>
            </div>
            <div className="space-y-2">
              {selections.map((sel, idx) => (
                <div key={idx} className="flex gap-2 items-center">
                  <input
                    placeholder="Label"
                    value={sel.label}
                    onChange={(e) => updateSelection(idx, 'label', e.target.value)}
                    className={`${inputCls} flex-1 min-w-0`}
                  />
                  <div className="relative w-20">
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Odd"
                      value={sel.odds || ''}
                      onChange={(e) => updateSelection(idx, 'odds', e.target.value)}
                      className={inputCls}
                    />
                  </div>
                  <div className="relative w-20">
                    <input
                      type="number"
                      step="1"
                      placeholder="%"
                      value={sel.probability || ''}
                      onChange={(e) => updateSelection(idx, 'probability', e.target.value)}
                      className={inputCls}
                    />
                  </div>
                  <button type="button" onClick={() => removeSelection(idx)} className="p-2 text-slate-400 hover:text-red-400 flex-shrink-0">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Preencha a odd e probabilidade de cada seleção. A soma das probabilidades deve chegar perto de 100%.
            </p>
          </div>

          <Field label="Recomendação (opcional)">
            <textarea
              value={recommendation}
              onChange={(e) => setRecommendation(e.target.value)}
              rows={2}
              className={inputCls}
              placeholder="Ex: Recomendado Acima 2.5 gols pela média ofensiva..."
            />
          </Field>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 disabled:opacity-50 flex items-center justify-center gap-2">
              {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
              Salvar Mercado
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================================
// HISTORY EDITOR — last games for each team
// ============================================================
function HistoryEditor({
  matchId,
  homeTeam,
  awayTeam,
  onRefresh,
}: {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  onRefresh: () => void;
}) {
  const [history, setHistory] = useState<MatchHistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<MatchHistoryEntry | null>(null);
  const [historyType, setHistoryType] = useState<HistoryType>('recent');

  useEffect(() => {
    loadHistory();
  }, [matchId]);

  async function loadHistory() {
    setLoading(true);
    const { data } = await supabase
      .from('match_history')
      .select('*')
      .eq('match_id', matchId)
      .order('date', { ascending: false });
    setHistory((data as MatchHistoryEntry[]) ?? []);
    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('Excluir este registro?')) return;
    await supabase.from('match_history').delete().eq('id', id);
    loadHistory();
    onRefresh();
  }

  const visibleHistory = history.filter((h) => h.history_type === historyType);
  const homeHistory = visibleHistory.filter((h) => h.team_name === homeTeam);
  const awayHistory = visibleHistory.filter((h) => h.team_name === awayTeam);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-blue-400" />
          Histórico do confronto
          <span className="text-slate-500 font-normal">({visibleHistory.length})</span>
        </h4>
        <button
          onClick={() => { setEditingEntry(null); setHistoryType(historyType); setShowForm(true); }}
          className="flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg bg-blue-500/10 text-blue-400 text-xs font-semibold hover:bg-blue-500/20 transition-colors"
        >
          <Plus className="w-4 h-4" /> Adicionar registro
        </button>
      </div>

      <div className="flex gap-1 p-1 rounded-xl bg-slate-950/60 border border-slate-700 mb-4 max-w-md">
        {([['recent', 'Últimos jogos'], ['h2h', 'Confronto direto']] as const).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setHistoryType(key)}
            className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold transition-colors ${historyType === key ? 'bg-blue-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            {label} ({history.filter((h) => h.history_type === key).length})
          </button>
        ))}
      </div>

      {loading ? (
        <Loader2 className="w-5 h-5 text-slate-500 animate-spin" />
      ) : visibleHistory.length === 0 ? (
        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700 border-dashed text-center">
          <p className="text-slate-500 text-sm">
            Nenhum histórico cadastrado.
          </p>
          <p className="text-slate-600 text-xs mt-1">
            Clique em "Adicionar registro" para incluir dados nesta aba.
          </p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {[{ name: homeTeam, items: homeHistory, logo: homeHistory.find(h => h.team_logo)?.team_logo }, { name: awayTeam, items: awayHistory, logo: awayHistory.find(h => h.team_logo)?.team_logo }].map(({ name, items, logo }) => (
            <div key={name} className="bg-slate-800/40 rounded-xl border border-slate-700 p-4">
              <p className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                {logo ? (
                  <img src={logo} alt="" className="w-7 h-7 rounded-lg object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                ) : (
                  <span className="w-7 h-7 rounded-lg bg-slate-700 flex items-center justify-center text-xs font-bold">
                    {name.charAt(0).toUpperCase()}
                  </span>
                )}
                {name}
                <span className="text-slate-500 font-normal text-xs">({items.length})</span>
              </p>
              {items.length === 0 ? (
                <p className="text-slate-600 text-xs">Sem jogos cadastrados.</p>
              ) : (
                <div className="space-y-1.5">
                  {items.map((h) => (
                    <div key={h.id} className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/40">
                      <span className={`w-6 h-6 rounded text-xs font-bold text-white flex items-center justify-center flex-shrink-0 ${
                        h.result === 'W' ? 'bg-emerald-500' : h.result === 'D' ? 'bg-slate-500' : 'bg-red-500'
                      }`}>
                        {h.result === 'W' ? 'V' : h.result === 'D' ? 'E' : 'D'}
                      </span>
                      {h.opponent_logo ? (
                        <img src={h.opponent_logo} alt="" className="w-6 h-6 rounded object-cover flex-shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <span className="w-6 h-6 rounded bg-slate-700 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                          {h.opponent.charAt(0).toUpperCase()}
                        </span>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white truncate">vs {h.opponent}</p>
                        <p className="text-xs text-slate-500">
                          {h.score && `${h.score} • `}{h.competition}
                          {h.date && ` • ${new Date(h.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}`}
                        </p>
                      </div>
                      <button onClick={() => { setEditingEntry(h); setShowForm(true); }} className="p-1 rounded text-slate-400 hover:text-emerald-400">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => handleDelete(h.id)} className="p-1 rounded text-slate-400 hover:text-red-400">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <HistoryFormModal
          matchId={matchId}
          entry={editingEntry}
          defaultHistoryType={historyType}
          homeTeam={homeTeam}
          awayTeam={awayTeam}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); loadHistory(); onRefresh(); }}
        />
      )}
    </div>
  );
}

// ============================================================
// HISTORY FORM MODAL
// ============================================================
function HistoryFormModal({
  matchId,
  entry,
  defaultHistoryType,
  homeTeam,
  awayTeam,
  onClose,
  onSaved,
}: {
  matchId: string;
  entry: MatchHistoryEntry | null;
  defaultHistoryType: HistoryType;
  homeTeam: string;
  awayTeam: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    history_type: entry?.history_type ?? defaultHistoryType,
    team_name: entry?.team_name ?? homeTeam,
    opponent: entry?.opponent ?? '',
    result: entry?.result ?? 'W',
    score: entry?.score ?? '',
    date: entry?.date ? toLocalDateInput(entry.date) : toLocalDateInput(new Date().toISOString()),
    competition: entry?.competition ?? '',
    team_logo: entry?.team_logo ?? '',
    opponent_logo: entry?.opponent_logo ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      match_id: matchId,
      history_type: form.history_type,
      team_name: form.team_name,
      opponent: form.opponent,
      result: form.result,
      score: form.score,
      date: new Date(form.date + 'T12:00:00').toISOString(),
      competition: form.competition,
      team_logo: form.team_logo || null,
      opponent_logo: form.opponent_logo || null,
    };
    let result;
    if (entry) {
      result = await supabase.from('match_history').update(payload).eq('id', entry.id);
    } else {
      result = await supabase.from('match_history').insert(payload);
    }

    if (result.error) {
      setError(result.error.message);
      setSaving(false);
      return;
    }
    setSaving(false);
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h2 className="text-lg font-bold text-white">
            {entry ? 'Editar Jogo' : 'Adicionar ao Histórico'}
          </h2>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <Field label="Tipo de registro">
            <select value={form.history_type} onChange={(e) => setForm({ ...form, history_type: e.target.value as HistoryType })} className={inputCls}>
              <option value="recent">Último jogo do time</option>
              <option value="h2h">Confronto direto entre os times</option>
            </select>
          </Field>

          <Field label="Time">
            <select value={form.team_name} onChange={(e) => setForm({ ...form, team_name: e.target.value })} className={inputCls}>
              <option value={homeTeam}>{homeTeam}</option>
              <option value={awayTeam}>{awayTeam}</option>
            </select>
          </Field>

          <Field label="Adversário">
            <input required value={form.opponent} onChange={(e) => setForm({ ...form, opponent: e.target.value })} className={inputCls} />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Logo do time (URL da foto)">
              <input value={form.team_logo} onChange={(e) => setForm({ ...form, team_logo: e.target.value })} placeholder="https://..." className={inputCls} />
            </Field>
            <Field label="Logo do adversário (URL da foto)">
              <input value={form.opponent_logo} onChange={(e) => setForm({ ...form, opponent_logo: e.target.value })} placeholder="https://..." className={inputCls} />
            </Field>
          </div>

          {(form.team_logo || form.opponent_logo) && (
            <div className="flex items-center gap-4 p-3 rounded-lg bg-slate-900/40 border border-slate-700">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Time:</span>
                {form.team_logo ? (
                  <img src={form.team_logo} alt="" className="w-8 h-8 rounded-lg object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                ) : <span className="w-8 h-8 rounded-lg bg-slate-700" />}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Adversário:</span>
                {form.opponent_logo ? (
                  <img src={form.opponent_logo} alt="" className="w-8 h-8 rounded-lg object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                ) : <span className="w-8 h-8 rounded-lg bg-slate-700" />}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <Field label="Resultado">
              <select value={form.result} onChange={(e) => setForm({ ...form, result: e.target.value as 'W' | 'D' | 'L' })} className={inputCls}>
                <option value="W">Vitória</option>
                <option value="D">Empate</option>
                <option value="L">Derrota</option>
              </select>
            </Field>
            <Field label="Placar">
              <input value={form.score} onChange={(e) => setForm({ ...form, score: e.target.value })} placeholder="Ex: 2-1" className={inputCls} />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Data">
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Competição">
              <input value={form.competition} onChange={(e) => setForm({ ...form, competition: e.target.value })} className={inputCls} />
            </Field>
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 disabled:opacity-50 flex items-center justify-center gap-2">
              {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================================
// IMPORT MATCHES — fetch real games from API and import selected
// ============================================================
interface ImportMatch {
  home_team: string;
  away_team: string;
  league: string;
  match_date: string;
  status: string;
  home_logo: string;
  away_logo: string;
  league_logo: string;
  fixture_id?: number;
}

function formatImportDate(value: string): string {
  const timestamp = Date.parse(value);
  if (Number.isNaN(timestamp)) return 'Data indisponível';
  return new Date(timestamp).toLocaleString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function ImportMatchesModal({
  onClose,
  onSaved,
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const [date, setDate] = useState(toLocalDateInput(new Date().toISOString()));
  const [results, setResults] = useState<ImportMatch[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);
  const [autoAnalyze, setAutoAnalyze] = useState(true);

  async function handleSearch() {
    setLoading(true);
    setError(null);
    setResults([]);
    setSelected(new Set());
    setSearched(false);

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/import-matches?date=${date}`;
      const res = await fetch(apiUrl, {
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => null);
        throw new Error(errData?.error ?? `Erro ${res.status}`);
      }

      const data = await res.json();
      const matches: ImportMatch[] = (data.matches ?? []).filter((match: ImportMatch) =>
        Boolean(match.home_team?.trim() && match.away_team?.trim() && match.match_date && !Number.isNaN(Date.parse(match.match_date)))
      );
      setResults(matches);
      if (matches.length > 0) {
        setSelected(new Set(matches.map((_, i) => i)));
      }
      setSearched(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao buscar jogos');
    } finally {
      setLoading(false);
    }
  }

  function toggleSelect(idx: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  }

  function toggleAll() {
    if (selected.size === results.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(results.map((_, i) => i)));
    }
  }

  async function handleImport() {
    const toImport = results.filter((_, i) => selected.has(i));
    if (toImport.length === 0) return;

    setImporting(true);
    setError(null);

    if (autoAnalyze) {
      try {
        // For auto-analyze, insert matches then generate markets via edge function
        const payload = toImport.map((m) => ({
          home_team: m.home_team,
          away_team: m.away_team,
          league: m.league,
          match_date: new Date(m.match_date).toISOString(),
          status: m.status,
          home_logo: m.home_logo || null,
          away_logo: m.away_logo || null,
          fixture_id: m.fixture_id ?? null,
          best_market: '',
          best_pick: '',
          best_pick_odds: 0,
          best_pick_probability: 0,
          analysis_summary: '',
        }));

        const { data: inserted, error: insertError } = await supabase.from('matches').insert(payload).select('id, home_team, away_team, home_logo, away_logo, fixture_id');

        if (insertError) {
          setError(insertError.message);
          setImporting(false);
          return;
        }

        // Generate markets for each inserted match via the analyze edge function
        if (inserted) {
          for (const ins of inserted) {
            const fixtureParam = ins.fixture_id ? `&fixture_id=${ins.fixture_id}` : '';
            await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/import-matches?analyze=true&match_id=${ins.id}&home=${encodeURIComponent(ins.home_team)}&away=${encodeURIComponent(ins.away_team)}${fixtureParam}${ins.home_logo ? `&home_logo=${encodeURIComponent(ins.home_logo)}` : ''}${ins.away_logo ? `&away_logo=${encodeURIComponent(ins.away_logo)}` : ''}`, {
              headers: {
                Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
                'Content-Type': 'application/json',
              },
            });
          }
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro ao importar');
        setImporting(false);
        return;
      }
    } else {
      const payload = toImport.map((m) => ({
        home_team: m.home_team,
        away_team: m.away_team,
        league: m.league,
        match_date: new Date(m.match_date).toISOString(),
        status: m.status,
        home_logo: m.home_logo || null,
        away_logo: m.away_logo || null,
        fixture_id: m.fixture_id ?? null,
        best_market: '',
        best_pick: '',
        best_pick_odds: 0,
        best_pick_probability: 0,
        analysis_summary: '',
      }));

      const { error: insertError } = await supabase.from('matches').insert(payload);

      if (insertError) {
        setError(insertError.message);
        setImporting(false);
        return;
      }
    }

    setImporting(false);
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-slate-700 sticky top-0 bg-slate-800 z-10">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Download className="w-5 h-5 text-sky-400" />
              Importar jogos da API BSD
            </h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="inline-flex items-center gap-1 text-xs font-bold text-sky-400 bg-sky-400/10 px-2 py-0.5 rounded-full uppercase tracking-wide">BSD/GoalDir v2</span>
              <p className="text-sm text-slate-400">Busque jogos reais por data, selecione e importe.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Auto-analyze toggle */}
          <label className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/40 border border-slate-700 cursor-pointer hover:border-slate-600">
            <input
              type="checkbox"
              checked={autoAnalyze}
              onChange={(e) => setAutoAnalyze(e.target.checked)}
              className="w-4 h-4 rounded accent-emerald-500"
            />
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <div className="flex-1">
              <p className="text-sm font-medium text-white">Gerar análises com previsões reais da API</p>
              <p className="text-xs text-slate-400">Busca previsões ML, odds, H2H e forma recente dos times diretamente da API BSD para cada jogo importado</p>
            </div>
          </label>

          <div className="flex flex-col sm:flex-row gap-3 items-end">
            <div className="flex-1 w-full">
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Data</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={inputCls}
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={loading || !date}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 text-white font-semibold hover:bg-sky-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
              Buscar jogos
            </button>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
            </div>
          )}

          {!loading && searched && results.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <Search className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p>Nenhum jogo encontrado para esta data na API BSD.</p>
            </div>
          )}

          {!loading && results.length > 0 && (
            <>
              <div className="flex items-center justify-between gap-3 bg-slate-900/40 rounded-lg p-3">
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selected.size === results.length}
                    onChange={toggleAll}
                    className="w-4 h-4 rounded accent-emerald-500"
                  />
                  Selecionar tudo ({results.length})
                </label>
                <span className="text-sm text-slate-400">
                  {selected.size} selecionado{selected.size !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="space-y-2 max-h-[40vh] overflow-y-auto">
                {results.map((m, idx) => {
                  const isSelected = selected.has(idx);
                  return (
                    <label
                      key={idx}
                      className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-500/10 border-emerald-500/40'
                          : 'bg-slate-900/40 border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(idx)}
                        className="w-4 h-4 rounded accent-emerald-500 flex-shrink-0"
                      />
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {m.home_logo && (
                          <img src={m.home_logo} alt="" className="w-7 h-7 object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0 text-sm">
                        <p className="text-white font-medium truncate">
                          {m.home_team} <span className="text-slate-500">vs</span> {m.away_team}
                        </p>
                        <p className="text-xs text-slate-400 mt-0.5">
                          {m.league || 'Futebol'} • {formatImportDate(m.match_date)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {m.away_logo && (
                          <img src={m.away_logo} alt="" className="w-7 h-7 object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                        )}
                        <span className={`text-xs font-medium px-2 py-1 rounded-lg ${
                          m.status === 'live' ? 'text-red-400 bg-red-400/10' :
                          m.status === 'finished' ? 'text-slate-400 bg-slate-700/30' :
                          'text-emerald-400 bg-emerald-400/10'
                        }`}>
                          {m.status === 'live' ? 'Ao vivo' : m.status === 'finished' ? 'Encerrado' : 'Em breve'}
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-700">
                <p className="text-sm text-slate-400">
                  {selected.size} jogo{selected.size !== 1 ? 's' : ''} para importar
                </p>
                <div className="flex gap-3">
                  <button type="button" onClick={onClose} className="px-5 py-2.5 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors">
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleImport}
                    disabled={importing || selected.size === 0}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {importing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                    Importar ({selected.size})
                  </button>
                </div>
              </div>
            </>
          )}

          {!loading && !searched && (
            <div className="text-center py-12 text-slate-500">
              <Download className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p>Escolha uma data e clique em "Buscar jogos".</p>
              <p className="text-xs text-slate-600 mt-2">
                Os jogos vêm com times, logos, data e status reais automaticamente.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
