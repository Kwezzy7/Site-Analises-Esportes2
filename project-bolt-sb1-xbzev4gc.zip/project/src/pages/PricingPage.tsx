import { useState } from 'react';
import { ArrowLeft, Check, CreditCard, Crown, Loader2, Lock, Zap } from 'lucide-react';

interface PricingPageProps {
  onBack: () => void;
}

const plans = [
  {
    name: 'Mensal',
    price: 'R$ 49',
    period: '/mês',
    badge: null,
    icon: Zap,
    accent: 'border-slate-700 bg-slate-800/50',
    button: 'bg-slate-700 hover:bg-slate-600 text-white',
    features: [
      'Acesso a todas as análises de futebol',
      'Mercados: gols, escanteios, ambas marcam, resultado',
      'Histórico e confronto direto de cada jogo',
      'Status ao vivo atualizado automaticamente',
      'Cancelamento a qualquer momento',
    ],
  },
  {
    name: 'Trimestral',
    price: 'R$ 119',
    period: '/3 meses',
    badge: 'Mais popular',
    icon: Crown,
    accent: 'border-emerald-500/40 bg-emerald-500/5',
    button: 'bg-emerald-500 hover:bg-emerald-600 text-white',
    features: [
      'Tudo do plano mensal',
      'Economia de R$ 28 frente ao mensal',
      'Prioridade na fila de novas análises',
      'Acesso antecipado a NBA e UFC (em breve)',
    ],
  },
  {
    name: 'Anual',
    price: 'R$ 399',
    period: '/ano',
    badge: 'Melhor valor',
    icon: Lock,
    accent: 'border-amber-500/30 bg-amber-500/5',
    button: 'bg-amber-500 hover:bg-amber-600 text-white',
    features: [
      'Tudo do plano trimestral',
      'Economia de R$ 189 frente ao mensal',
      'Selo de apoiador no perfil',
      'Acesso a todos os esportes futuros',
    ],
  },
];

export default function PricingPage({ onBack }: PricingPageProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);

  function handleSubscribe(planName: string) {
    setSelectedPlan(planName);
    setProcessing(true);
    setDone(false);
    window.setTimeout(() => {
      setProcessing(false);
      setDone(true);
    }, 2000);
  }

  return (
    <main className="min-h-[calc(100vh-76px)] bg-slate-950 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <button onClick={onBack} className="mb-8 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-slate-400 transition-colors hover:bg-slate-800 hover:text-white">
          <ArrowLeft className="h-4 w-4" /> Voltar
        </button>

        <section className="text-center mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-emerald-300">
            <CreditCard className="h-3.5 w-3.5" /> Planos
          </div>
          <h1 className="mt-5 text-3xl font-bold tracking-tight text-white sm:text-5xl">
            Escolha seu <span className="text-emerald-400">acesso</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-slate-400">
            Desbloqueie todas as análises, mercados e histórico de jogos. O pagamento está em desenvolvimento — você pode reservar seu plano agora e pagar quando o sistema estiver pronto.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-amber-500/10 border border-amber-500/20 px-4 py-2 text-xs font-semibold text-amber-300">
            <Lock className="h-3.5 w-3.5" /> Sistema de pagamento em desenvolvimento
          </div>
        </section>

        <div className="grid gap-5 md:grid-cols-3">
          {plans.map(({ name, price, period, badge, icon: Icon, accent, button, features }) => (
            <div key={name} className={`relative rounded-2xl border p-6 ${accent}`}>
              {badge && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-emerald-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white">
                  {badge}
                </span>
              )}
              <Icon className="h-8 w-8 text-emerald-400" />
              <h2 className="mt-4 text-lg font-bold text-white">{name}</h2>
              <p className="mt-2 text-3xl font-bold text-white">
                {price}<span className="text-base font-normal text-slate-400">{period}</span>
              </p>
              <ul className="mt-6 space-y-3">
                {features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5 text-sm text-slate-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                    {feature}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleSubscribe(name)}
                disabled={processing && selectedPlan === name}
                className={`mt-6 w-full rounded-xl py-3 text-sm font-bold transition-colors disabled:opacity-50 ${button}`}
              >
                {processing && selectedPlan === name ? (
                  <span className="flex items-center justify-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Processando...</span>
                ) : done && selectedPlan === name ? (
                  <span className="flex items-center justify-center gap-2"><Check className="h-4 w-4" /> Reservado!</span>
                ) : (
                  'Escolher plano'
                )}
              </button>
            </div>
          ))}
        </div>

        {done && (
          <div className="mt-8 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
            <Check className="mx-auto h-8 w-8 text-emerald-400" />
            <p className="mt-3 text-lg font-bold text-white">Plano reservado com sucesso!</p>
            <p className="mt-1 text-sm text-slate-300">
              Seu plano <strong className="text-emerald-300">{selectedPlan}</strong> está reservado. Assim que o pagamento estiver disponível, você será avisado para concluir a ativação.
            </p>
          </div>
        )}

        <p className="mt-8 text-center text-xs text-slate-500">
          Os preços são ilustrativos e podem mudar quando o pagamento for liberado. Nenhum cobrança é feita agora.
        </p>
      </div>
    </main>
  );
}
