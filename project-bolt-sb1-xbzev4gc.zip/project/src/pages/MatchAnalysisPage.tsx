import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  TrendingUp,
  Loader2,
  Target,
  Flag,
  Goal,
  ClipboardList,
  Trophy,
  LockKeyhole,
  Shield,
  Crosshair,
  Zap,
  Layers,
  BarChart3,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Match, MatchMarket, MatchHistoryEntry } from '@/lib/types';
import { MARKET_LABELS, MARKET_PRESETS } from '@/lib/types';
import { useAuth } from '@/context/AuthContext';

interface MatchAnalysisPageProps {
  matchId: string;
  onBack: () => void;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function probColor(prob: number) {
  if (prob >= 70) return 'bg-emerald-500';
  if (prob >= 50) return 'bg-yellow-500';
  if (prob >= 30) return 'bg-orange-500';
  return 'bg-red-500';
}

function resultColor(result: string) {
  if (result === 'W') return 'bg-emerald-500';
  if (result === 'D') return 'bg-slate-500';
  return 'bg-red-500';
}

function resultLabel(result: string) {
  if (result === 'W') return 'V';
  if (result === 'D') return 'E';
  return 'D';
}

function normalizeTeamName(name: string) {
  return name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

const ICON_MAP: Record<string, typeof Target> = {
  goal: Goal,
  flag: Flag,
  target: Target,
  trophy: Trophy,
  card: Shield,
};

type MarketGroupKey = 'Resultado' | 'Handicap' | 'Gols' | 'Ambas Marcam' | 'Escanteios' | 'Cartões' | 'Finalizações' | 'Estatísticas';

const MARKET_GROUP_TABS: { key: MarketGroupKey; label: string; icon: typeof Target }[] = [
  { key: 'Resultado', label: 'Resultado', icon: Trophy },
  { key: 'Handicap', label: 'Handicap', icon: Layers },
  { key: 'Gols', label: 'Gols', icon: Goal },
  { key: 'Ambas Marcam', label: 'Ambas Marcam', icon: Target },
  { key: 'Escanteios', label: 'Escanteios', icon: Flag },
  { key: 'Cartões', label: 'Cartões', icon: Shield },
  { key: 'Finalizações', label: 'Finalizações', icon: Crosshair },
  { key: 'Estatísticas', label: 'Estatísticas', icon: BarChart3 },
];

export default function MatchAnalysisPage({ matchId, onBack }: MatchAnalysisPageProps) {
  const { profile } = useAuth();
  const hasAccess = profile?.role === 'admin' || profile?.key_status === 'active';
  const [match, setMatch] = useState<Match | null>(null);
  const [markets, setMarkets] = useState<MatchMarket[]>([]);
  const [history, setHistory] = useState<MatchHistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeGroup, setActiveGroup] = useState<MarketGroupKey>('Resultado');

  useEffect(() => {
    loadData();
  }, [matchId]);

  async function loadData() {
    setLoading(true);
    const [matchRes, marketsRes, historyRes] = await Promise.all([
      supabase.from('matches').select('*').eq('id', matchId).maybeSingle(),
      supabase.from('match_markets').select('*').eq('match_id', matchId),
      supabase.from('match_history').select('*').eq('match_id', matchId),
    ]);

    if (matchRes.data) setMatch(matchRes.data as Match);
    if (marketsRes.data) setMarkets(marketsRes.data as MatchMarket[]);
    if (historyRes.data) setHistory(historyRes.data as MatchHistoryEntry[]);
    setLoading(false);
  }

  const activeMarkets = markets.filter((market) => {
    const preset = MARKET_PRESETS.find((item) => item.key === market.market_type);
    return preset?.group === activeGroup;
  });
  const visibleGroups = MARKET_GROUP_TABS.filter((tab) =>
    markets.some((market) => MARKET_PRESETS.find((item) => item.key === market.market_type)?.group === tab.key)
  );
  const recentHistory = history.filter((item) => item.history_type === 'recent');
  const directHistory = history.filter((item) => item.history_type === 'h2h');

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (!match) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 text-lg">Jogo não encontrado.</p>
          <button
            onClick={onBack}
            className="mt-4 text-emerald-400 hover:underline"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/30 border-b border-slate-800">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Voltar aos jogos</span>
          </button>

          <div className="text-center">
            <span className="text-sm font-medium text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full">
              {match.league}
            </span>
            {match.status === 'live' && <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-red-500/15 px-3 py-1 text-xs font-bold text-red-300"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" /> AO VIVO</span>}
            <div className="flex items-center justify-center gap-6 sm:gap-12 my-6">
              <div className="flex flex-col items-center gap-3 flex-1 max-w-[200px]">
                {match.home_logo && (match.home_logo.startsWith('http') || match.home_logo.startsWith('/')) ? (
                  <img src={match.home_logo} alt={match.home_team} className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                ) : (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-700 flex items-center justify-center text-2xl sm:text-3xl font-bold text-white">
                    {match.home_logo || match.home_team.charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="text-base sm:text-lg font-bold text-white text-center">
                  {match.home_team}
                </span>
              </div>
              <div className="text-slate-500 font-bold text-xl sm:text-2xl">VS</div>
              <div className="flex flex-col items-center gap-3 flex-1 max-w-[200px]">
                {match.away_logo && (match.away_logo.startsWith('http') || match.away_logo.startsWith('/')) ? (
                  <img src={match.away_logo} alt={match.away_team} className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                ) : (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-700 flex items-center justify-center text-2xl sm:text-3xl font-bold text-white">
                    {match.away_logo || match.away_team.charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="text-base sm:text-lg font-bold text-white text-center">
                  {match.away_team}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-center gap-2 text-slate-400 text-sm">
              <Calendar className="w-4 h-4" />
              {formatDate(match.match_date)}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {!hasAccess && (
          <div className="relative overflow-hidden rounded-3xl border border-amber-400/25 bg-gradient-to-br from-amber-500/15 via-slate-900 to-slate-900 p-7 sm:p-9 text-center shadow-xl shadow-black/20">
            <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-amber-400/10 blur-3xl" />
            <LockKeyhole className="relative mx-auto w-10 h-10 text-amber-300" />
            <p className="relative mt-4 text-xs font-bold uppercase tracking-[0.2em] text-amber-300">Análise protegida</p>
            <h2 className="relative mt-2 text-2xl font-bold text-white">Ative sua key para desbloquear este jogo</h2>
            <p className="relative mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-300">Você pode ver o confronto, a data e os times. As probabilidades, mercados e histórico ficam disponíveis assim que um administrador liberar sua licença.</p>
            <div className="relative mt-5 inline-flex items-center rounded-xl border border-slate-700 bg-slate-950/50 px-4 py-2 text-sm text-slate-400">Status atual: <span className="ml-1.5 font-semibold text-amber-300">{profile?.key_status === 'revoked' ? 'key revogada' : 'aguardando ativação'}</span></div>
          </div>
        )}

        {hasAccess && <>
        {/* Best Market Highlight */}
        {match.best_market && match.best_pick && (
          <div className="bg-gradient-to-r from-emerald-500/15 to-emerald-500/5 rounded-2xl border border-emerald-500/30 p-6">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm mb-3">
              <TrendingUp className="w-5 h-5" />
              MELHOR MERCADO RECOMENDADO
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-2xl font-bold text-white">{match.best_market}</p>
                <p className="text-lg text-slate-300 mt-1">{match.best_pick}</p>
              </div>
              <div className="flex gap-6">
                {match.best_pick_odds > 0 && (
                  <div className="text-center">
                    <p className="text-xs text-slate-400 uppercase">Odd</p>
                    <p className="text-2xl font-bold text-white">
                      {match.best_pick_odds}
                    </p>
                  </div>
                )}
                {match.best_pick_probability > 0 && (
                  <div className="text-center">
                    <p className="text-xs text-slate-400 uppercase">Probabilidade</p>
                    <p className="text-2xl font-bold text-emerald-400">
                      {match.best_pick_probability}%
                    </p>
                  </div>
                )}
              </div>
            </div>
            {match.analysis_summary && (
              <p className="text-slate-300 text-sm mt-4 pt-4 border-t border-emerald-500/20">
                {match.analysis_summary}
              </p>
            )}
          </div>
        )}

        {/* Market Tabs */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-emerald-400" />
            Análise de Mercados
          </h2>

          {markets.length === 0 ? (
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center">
              <p className="text-slate-400">Nenhum mercado cadastrado para este jogo ainda.</p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap gap-2 mb-4">
                {visibleGroups.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => setActiveGroup(tab.key)}
                      className={`flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                        activeGroup === tab.key
                          ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>

              {activeMarkets.length === 0 ? (
                <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center">
                  <p className="text-slate-400">Este grupo ainda não possui análise cadastrada.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {activeMarkets.map((activeMarket) => (
                    <div key={activeMarket.id} className="bg-slate-800/50 rounded-2xl border border-slate-700 p-6">
                      <div className="flex items-center justify-between mb-5">
                        <h3 className="text-lg font-bold text-white">
                          {MARKET_LABELS[activeMarket.market_type]}
                          {activeMarket.line && <span className="text-slate-400 ml-2">— Linha {activeMarket.line}</span>}
                        </h3>
                      </div>
                      <div className="space-y-4">
                        {activeMarket.selections.map((sel, idx) => (
                          <div key={idx} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium text-white">{sel.label}</span>
                              <div className="flex items-center gap-4">
                                <span className="text-sm text-slate-400">Odd: <strong className="text-white">{sel.odds}</strong></span>
                                <span className="text-sm font-bold text-emerald-400 w-16 text-right">{sel.probability}%</span>
                              </div>
                            </div>
                            <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
                              <div className={`h-full rounded-full transition-all duration-500 ${probColor(sel.probability)}`} style={{ width: `${Math.min(sel.probability, 100)}%` }} />
                            </div>
                          </div>
                        ))}
                      </div>
                      {activeMarket.recommendation && (
                        <div className="mt-5 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                          <p className="text-xs font-semibold text-emerald-400 mb-1">RECOMENDAÇÃO</p>
                          <p className="text-sm text-slate-200">{activeMarket.recommendation}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        </>}

        {/* Direct confrontations */}
        {hasAccess && directHistory.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              Confronto Direto
            </h2>
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-4 sm:p-6">
              <div className="space-y-2">
                {directHistory.map((item) => (
                  <div key={item.id} className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-900/40">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className={`w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold text-white ${resultColor(item.result)}`}>
                        {resultLabel(item.result)}
                      </span>
                      {item.team_logo ? (
                        <img src={item.team_logo} alt="" className="w-7 h-7 rounded-md object-cover flex-shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <span className="w-7 h-7 rounded-md bg-slate-700 flex items-center justify-center text-xs font-bold flex-shrink-0">{item.team_name.charAt(0).toUpperCase()}</span>
                      )}
                      <span className="text-slate-500 text-xs">vs</span>
                      {item.opponent_logo ? (
                        <img src={item.opponent_logo} alt="" className="w-7 h-7 rounded-md object-cover flex-shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <span className="w-7 h-7 rounded-md bg-slate-700 flex items-center justify-center text-xs font-bold flex-shrink-0">{item.opponent.charAt(0).toUpperCase()}</span>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm text-white truncate">{item.team_name} vs {item.opponent}</p>
                        <p className="text-xs text-slate-500">{item.competition} {item.date && `• ${new Date(item.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}`}</p>
                      </div>
                    </div>
                    <span className="text-sm font-bold text-slate-200">{item.score || '—'}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Recent Form / History */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            Últimos Jogos
          </h2>

          {recentHistory.length === 0 ? (
            <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center">
              <p className="text-slate-400">Nenhum último jogo cadastrado para este confronto.</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {[match.home_team, match.away_team].map((team) => {
                const teamHistory = recentHistory.filter((h) => normalizeTeamName(h.team_name) === normalizeTeamName(team));
                return (
                  <div
                    key={team}
                    className="bg-slate-800/50 rounded-2xl border border-slate-700 p-5"
                  >
                    <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                      {recentHistory.find((h) => normalizeTeamName(h.team_name) === normalizeTeamName(team) && h.team_logo)?.team_logo ? (
                        <img src={recentHistory.find((h) => normalizeTeamName(h.team_name) === normalizeTeamName(team) && h.team_logo)!.team_logo!} alt="" className="w-8 h-8 rounded-lg object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <span className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center text-sm font-bold">
                          {team.charAt(0).toUpperCase()}
                        </span>
                      )}
                      {team}
                    </h3>
                    {teamHistory.length === 0 ? (
                      <p className="text-slate-500 text-sm">Sem histórico.</p>
                    ) : (
                      <div className="space-y-2">
                        {teamHistory.map((h) => (
                          <div
                            key={h.id}
                            className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/40"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <span
                                className={`w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold text-white ${resultColor(h.result)}`}
                              >
                                {resultLabel(h.result)}
                              </span>
                              {h.opponent_logo ? (
                                <img src={h.opponent_logo} alt="" className="w-7 h-7 rounded-md object-cover flex-shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                              ) : (
                                <span className="w-7 h-7 rounded-md bg-slate-700 flex items-center justify-center text-xs font-bold flex-shrink-0">{h.opponent.charAt(0).toUpperCase()}</span>
                              )}
                              <div className="min-w-0">
                                <p className="text-sm text-white truncate">
                                  vs {h.opponent}
                                </p>
                                <p className="text-xs text-slate-500">
                                  {h.competition}
                                  {h.date &&
                                    ` • ${new Date(h.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}`}
                                </p>
                              </div>
                            </div>
                            {h.score && (
                              <span className="text-sm font-semibold text-slate-300 ml-2">
                                {h.score}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
