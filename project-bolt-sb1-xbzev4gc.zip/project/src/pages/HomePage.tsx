import { useEffect, useState, useMemo } from 'react';
import {
  Calendar,
  ChevronRight,
  Loader2,
  Flame,
  Search,
  Trophy,
  ChevronDown,
  LockKeyhole,
  Sparkles,
  Radio,
  TrendingUp,
  BarChart3,
  ArrowRight,
  Star,
  Target,
  Zap,
  Clock,
  Activity,
  Award,
  Layers,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { Match } from '@/lib/types';

interface HomePageProps {
  onMatchClick: (matchId: string) => void;
}

function formatTime(dateStr: string) {
  return new Date(dateStr).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function formatDayHeader(dateStr: string) {
  const d = new Date(dateStr);
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  const isToday = d.toDateString() === today.toDateString();
  const isTomorrow = d.toDateString() === tomorrow.toDateString();
  const dayLabel = isToday ? 'Hoje' : isTomorrow ? 'Amanhã' : d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
  return dayLabel.charAt(0).toUpperCase() + dayLabel.slice(1);
}

function TeamLogo({ logo, name, size }: { logo: string; name: string; size: string }) {
  if (logo && (logo.startsWith('http') || logo.startsWith('/'))) {
    return (
      <img src={logo} alt={name} className={`${size} rounded-xl object-contain bg-slate-800/60 p-1`} onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
    );
  }
  return (
    <div className={`${size} rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center text-lg font-bold text-white`}>
      {logo || name.charAt(0).toUpperCase()}
    </div>
  );
}

function statusBadge(status: string) {
  if (status === 'live')
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-400 bg-red-500/15 px-2 py-0.5 rounded-full uppercase tracking-wide">
        <Radio className="w-3 h-3 animate-pulse" /> Ao vivo
      </span>
    );
  if (status === 'finished')
    return (
      <span className="text-[10px] font-semibold text-slate-400 bg-slate-700/40 px-2 py-0.5 rounded-full uppercase tracking-wide">
        Encerrado
      </span>
    );
  return (
    <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full uppercase tracking-wide">
      Em breve
    </span>
  );
}

interface DayGroup {
  date: string;
  label: string;
  matches: Match[];
}

export default function HomePage({ onMatchClick }: HomePageProps) {
  const { profile } = useAuth();
  const hasAccess = profile?.role === 'admin' || profile?.key_status === 'active';
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'live' | 'finished'>('all');
  const [leagueFilter, setLeagueFilter] = useState<string>('all');
  const [expandedDays, setExpandedDays] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadMatches();
  }, []);

  async function loadMatches() {
    const { data, error } = await supabase
      .from('matches')
      .select('*')
      .order('match_date', { ascending: true });

    if (error) {
      console.error('Erro ao carregar jogos:', error.message);
    } else {
      setMatches((data as Match[]) ?? []);
    }
    setLoading(false);
  }

  // All unique leagues for filter
  const leagues = useMemo(() => {
    const set = new Set(matches.map((m) => m.league));
    return Array.from(set).sort();
  }, [matches]);

  const filtered = matches.filter((m) => {
    if (filter !== 'all' && m.status !== filter) return false;
    if (leagueFilter !== 'all' && m.league !== leagueFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        m.home_team.toLowerCase().includes(q) ||
        m.away_team.toLowerCase().includes(q) ||
        m.league.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const orderedMatches = [...filtered].sort((a, b) => new Date(a.match_date).getTime() - new Date(b.match_date).getTime());
  const dayGroups: DayGroup[] = [];
  const dayMap = new Map<string, Match[]>();
  for (const m of orderedMatches) {
    const dayKey = new Date(m.match_date).toDateString();
    if (!dayMap.has(dayKey)) dayMap.set(dayKey, []);
    dayMap.get(dayKey)!.push(m);
  }
  for (const [dayKey, dayMatches] of dayMap) {
    dayGroups.push({
      date: dayKey,
      label: formatDayHeader(dayMatches[0].match_date),
      matches: dayMatches,
    });
  }

  useEffect(() => {
    if (dayGroups.length > 0 && expandedDays.size === 0) {
      setExpandedDays(new Set(dayGroups.slice(0, 2).map((g) => g.date)));
    }
  }, [matches]);

  function toggleDay(date: string) {
    setExpandedDays((prev) => {
      const next = new Set(prev);
      if (next.has(date)) next.delete(date);
      else next.add(date);
      return next;
    });
  }

  const liveCount = matches.filter((m) => m.status === 'live').length;
  const upcomingCount = matches.filter((m) => m.status === 'upcoming').length;
  const analyzedCount = matches.filter((m) => m.best_market).length;
  const liveMatches = matches.filter((m) => m.status === 'live');

  // Featured match: first upcoming or first live
  const featuredMatch = matches.find((m) => m.status === 'upcoming' && m.best_market) ?? matches.find((m) => m.status === 'live' && m.best_market) ?? null;

  // Top picks: matches with best_pick, sorted by probability
  const topPicks = matches
    .filter((m) => m.best_market && m.best_pick_probability >= 55 && (m.status === 'upcoming' || m.status === 'live'))
    .sort((a, b) => (b.best_pick_probability ?? 0) - (a.best_pick_probability ?? 0))
    .slice(0, 5);

  // League stats
  const leagueStats = useMemo(() => {
    const map = new Map<string, { total: number; live: number; upcoming: number; analyzed: number }>();
    for (const m of matches) {
      if (!map.has(m.league)) map.set(m.league, { total: 0, live: 0, upcoming: 0, analyzed: 0 });
      const s = map.get(m.league)!;
      s.total++;
      if (m.status === 'live') s.live++;
      if (m.status === 'upcoming') s.upcoming++;
      if (m.best_market) s.analyzed++;
    }
    return Array.from(map.entries()).sort((a, b) => b[1].total - a[1].total).slice(0, 6);
  }, [matches]);

  const stats = [
    { label: 'Total', value: matches.length, color: 'text-white', icon: BarChart3, bg: 'from-slate-800/60 to-slate-800/30' },
    { label: 'Ao vivo', value: liveCount, color: 'text-red-400', icon: Radio, bg: 'from-red-950/40 to-slate-900/30' },
    { label: 'Em breve', value: upcomingCount, color: 'text-emerald-400', icon: Calendar, bg: 'from-emerald-950/40 to-slate-900/30' },
    { label: 'Analisados', value: analyzedCount, color: 'text-sky-400', icon: TrendingUp, bg: 'from-sky-950/40 to-slate-900/30' },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <div className="relative overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/20" />
        <div className="absolute top-0 left-1/4 w-[32rem] h-[32rem] bg-emerald-500/8 rounded-full blur-[6rem]" />
        <div className="absolute bottom-0 right-1/4 w-[24rem] h-[24rem] bg-sky-500/5 rounded-full blur-[5rem]" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-emerald-300">
                <Sparkles className="w-3.5 h-3.5" /> MatchLab
              </div>
              <h1 className="mt-4 text-4xl font-bold tracking-tight text-white sm:text-6xl">
                Jogos reais.<br />
                <span className="bg-gradient-to-r from-emerald-400 to-sky-400 bg-clip-text text-transparent">Análise que importa.</span>
              </h1>
              <p className="mt-5 max-w-xl text-base leading-7 text-slate-400">
                Calendário completo, status ao vivo e análise de mercados com probabilidades. Tudo organizado por dia e campeonato.
              </p>
              {liveCount > 0 && (
                <div className="mt-5 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20">
                  <Flame className="w-4 h-4 text-red-400 animate-pulse" />
                  <span className="text-sm font-bold text-red-400">{liveCount} jogo{liveCount !== 1 ? 's' : ''} ao vivo agora</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 lg:max-w-lg">
              {stats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div key={stat.label} className={`group relative overflow-hidden rounded-2xl border border-slate-700/60 bg-gradient-to-br ${stat.bg} backdrop-blur p-4 transition-all hover:border-slate-600`}>
                    <Icon className="absolute top-3 right-3 w-4 h-4 text-slate-600 group-hover:text-slate-500" />
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">{stat.label}</p>
                    <p className={`mt-1 text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Search + Filters */}
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar time ou campeonato..."
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-800/60 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
              />
            </div>
            {leagues.length > 1 && (
              <select
                value={leagueFilter}
                onChange={(e) => setLeagueFilter(e.target.value)}
                className="px-4 py-3 rounded-xl bg-slate-800/60 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all cursor-pointer"
              >
                <option value="all">Todos os campeonatos</option>
                {leagues.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            )}
            <div className="flex gap-1 bg-slate-800/60 rounded-xl p-1 border border-slate-700 overflow-x-auto">
              {([
                ['all', 'Todos'],
                ['upcoming', 'Em breve'],
                ['live', 'Ao vivo'],
                ['finished', 'Encerrados'],
              ] as const).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                    filter === key
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Featured Match + Top Picks */}
        {!search && filter === 'all' && leagueFilter === 'all' && (featuredMatch || topPicks.length > 0) && (
          <div className="grid lg:grid-cols-3 gap-4">
            {/* Featured Match */}
            {featuredMatch && (
              <button
                onClick={() => onMatchClick(featuredMatch.id)}
                className="group lg:col-span-2 relative overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 p-6 text-left transition-all hover:border-emerald-400/50 hover:shadow-2xl hover:shadow-emerald-500/10"
              >
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl" />
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-bold uppercase tracking-wider text-amber-400">Jogo em destaque</span>
                    </div>
                    {statusBadge(featuredMatch.status)}
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex flex-col items-center gap-2 flex-1">
                      <TeamLogo logo={featuredMatch.home_logo} name={featuredMatch.home_team} size="w-16 h-16" />
                      <span className="text-sm font-bold text-white text-center">{featuredMatch.home_team}</span>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <span className="text-slate-600 font-bold text-xs uppercase">VS</span>
                      <span className="text-xs text-slate-400">{formatTime(featuredMatch.match_date)}</span>
                      <span className="text-[10px] text-slate-500">{featuredMatch.league}</span>
                    </div>
                    <div className="flex flex-col items-center gap-2 flex-1">
                      <TeamLogo logo={featuredMatch.away_logo} name={featuredMatch.away_team} size="w-16 h-16" />
                      <span className="text-sm font-bold text-white text-center">{featuredMatch.away_team}</span>
                    </div>
                  </div>
                  {hasAccess && featuredMatch.best_market && (
                    <div className="mt-5 pt-4 border-t border-slate-700/50">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-emerald-400" />
                          <span className="text-sm text-white font-medium">{featuredMatch.best_market}</span>
                          <span className="text-xs text-slate-400">— {featuredMatch.best_pick}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-bold text-emerald-400">{featuredMatch.best_pick_probability}%</span>
                          <span className="text-sm text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded-lg">odd {featuredMatch.best_pick_odds}</span>
                        </div>
                      </div>
                      {featuredMatch.analysis_summary && (
                        <p className="mt-2 text-xs text-slate-400 leading-relaxed">{featuredMatch.analysis_summary}</p>
                      )}
                    </div>
                  )}
                  <div className="mt-4 flex items-center gap-1 text-sm font-semibold text-emerald-400 group-hover:gap-2 transition-all">
                    Ver análise completa <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </button>
            )}

            {/* Top Picks */}
            {topPicks.length > 0 && (
              <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
                <h3 className="flex items-center gap-2 text-sm font-bold text-white mb-4">
                  <Zap className="w-4 h-4 text-amber-400" /> Top picks
                </h3>
                <div className="space-y-2">
                  {topPicks.map((pick) => (
                    <button
                      key={pick.id}
                      onClick={() => onMatchClick(pick.id)}
                      className="w-full group flex items-center gap-3 p-3 rounded-xl bg-slate-800/40 hover:bg-slate-800/70 transition-all text-left"
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-amber-500/10 flex-shrink-0">
                        <span className="text-xs font-bold text-amber-400">{pick.best_pick_probability}%</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white font-medium truncate">{pick.home_team} vs {pick.away_team}</p>
                        <p className="text-[10px] text-slate-500 truncate">{pick.best_market} — {pick.best_pick}</p>
                      </div>
                      <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded flex-shrink-0">{pick.best_pick_odds}</span>
                      <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition-colors flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Live Section */}
        {liveMatches.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="flex items-center gap-2 text-lg font-bold text-white">
                <Radio className="w-5 h-5 text-red-400 animate-pulse" /> Ao vivo agora
              </h2>
              <span className="text-xs text-slate-500">{liveMatches.length} jogo{liveMatches.length !== 1 ? 's' : ''}</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {liveMatches.slice(0, 4).map((match) => (
                <button
                  key={match.id}
                  onClick={() => onMatchClick(match.id)}
                  className="group relative overflow-hidden rounded-2xl border border-red-500/30 bg-gradient-to-br from-red-950/30 to-slate-900 p-5 text-left transition-all hover:-translate-y-1 hover:border-red-400/50 hover:shadow-xl hover:shadow-red-500/10"
                >
                  <div className="absolute top-3 right-3">{statusBadge(match.status)}</div>
                  <p className="text-xs text-slate-400 truncate pr-16">{match.league}</p>
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center gap-2.5">
                      <TeamLogo logo={match.home_logo} name={match.home_team} size="w-9 h-9" />
                      <span className="text-sm font-semibold text-white truncate">{match.home_team}</span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <TeamLogo logo={match.away_logo} name={match.away_team} size="w-9 h-9" />
                      <span className="text-sm font-semibold text-white truncate">{match.away_team}</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between">
                    <span className="text-xs text-slate-400">{formatTime(match.match_date)}</span>
                    <span className="flex items-center gap-1 text-xs font-semibold text-red-400 group-hover:translate-x-1 transition-transform">
                      Ver análise <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* League Stats */}
        {!search && leagueStats.length > 1 && (
          <section>
            <h2 className="flex items-center gap-2 text-lg font-bold text-white mb-4">
              <Layers className="w-5 h-5 text-sky-400" /> Campeonatos
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {leagueStats.map(([leagueName, stats]) => (
                <button
                  key={leagueName}
                  onClick={() => setLeagueFilter(leagueName)}
                  className="group rounded-xl border border-slate-800 bg-slate-900/40 p-4 hover:border-sky-500/40 hover:bg-slate-800/60 transition-all text-left"
                >
                  <p className="text-xs font-bold text-white truncate group-hover:text-sky-400 transition-colors">{leagueName}</p>
                  <div className="mt-2 flex items-center gap-3 text-[10px] text-slate-400">
                    <span className="flex items-center gap-1"><Trophy className="w-3 h-3" /> {stats.total}</span>
                    {stats.live > 0 && <span className="flex items-center gap-1 text-red-400"><Radio className="w-3 h-3" /> {stats.live}</span>}
                    <span className="flex items-center gap-1 text-emerald-400"><Activity className="w-3 h-3" /> {stats.analyzed}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Full Match List */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
            <p className="mt-3 text-sm text-slate-500">Carregando jogos...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-800/50 mb-4">
              <Trophy className="w-10 h-10 text-slate-600" />
            </div>
            <p className="text-slate-400 text-lg font-medium">Nenhum jogo encontrado.</p>
            <p className="text-slate-500 text-sm mt-1">Os novos confrontos aparecerão aqui assim que forem importados.</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-lg font-bold text-white">
                <TrendingUp className="w-5 h-5 text-sky-400" /> Agenda
              </h2>
              <span className="text-xs text-slate-500">{filtered.length} jogo{filtered.length !== 1 ? 's' : ''}</span>
            </div>
            {dayGroups.map((day) => {
              const isExpanded = expandedDays.has(day.date);
              const dayLive = day.matches.filter((m) => m.status === 'live').length;

              const lgGroups = new Map<string, Match[]>();
              for (const m of day.matches) {
                if (!lgGroups.has(m.league)) lgGroups.set(m.league, []);
                lgGroups.get(m.league)!.push(m);
              }

              return (
                <div key={day.date} className="rounded-2xl border border-slate-800 bg-slate-900/30 overflow-hidden transition-all hover:border-slate-700">
                  <button
                    onClick={() => toggleDay(day.date)}
                    className="w-full flex items-center justify-between p-4 hover:bg-slate-800/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 text-white font-bold text-sm sm:text-base">
                        <Calendar className="w-4 h-4 text-emerald-400" />
                        {day.label}
                      </div>
                      <span className="text-xs text-slate-500">
                        {day.matches.length} jogo{day.matches.length !== 1 ? 's' : ''}
                      </span>
                      {dayLive > 0 && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-red-400 bg-red-500/10 px-2 py-0.5 rounded-full">
                          <Flame className="w-3 h-3" /> {dayLive} ao vivo
                        </span>
                      )}
                    </div>
                    <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </button>

                  {isExpanded && (
                    <div className="p-4 pt-0 space-y-3">
                      {Array.from(lgGroups.entries()).map(([lgName, lgMatches]) => (
                        <div key={lgName}>
                          <div className="flex items-center gap-2 mb-2 px-1">
                            <Trophy className="w-3.5 h-3.5 text-amber-400" />
                            <span className="text-xs font-semibold text-slate-400">{lgName}</span>
                            <div className="flex-1 h-px bg-slate-800" />
                          </div>
                          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                            {lgMatches.map((match) => (
                              <button
                                key={match.id}
                                onClick={() => onMatchClick(match.id)}
                                className="group relative text-left rounded-xl border border-slate-700/60 bg-slate-800/30 p-4 hover:border-emerald-500/40 hover:bg-slate-800/60 hover:shadow-lg hover:shadow-emerald-500/5 transition-all"
                              >
                                <div className="flex items-center justify-between mb-3">
                                  <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                                    <Clock className="w-3 h-3" /> {formatTime(match.match_date)}
                                  </span>
                                  {statusBadge(match.status)}
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
                                    <TeamLogo logo={match.home_logo} name={match.home_team} size="w-10 h-10" />
                                    <span className="text-xs font-medium text-white text-center truncate w-full">{match.home_team}</span>
                                  </div>
                                  <span className="text-slate-600 font-bold text-xs">VS</span>
                                  <div className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
                                    <TeamLogo logo={match.away_logo} name={match.away_team} size="w-10 h-10" />
                                    <span className="text-xs font-medium text-white text-center truncate w-full">{match.away_team}</span>
                                  </div>
                                </div>
                                <div className="mt-3 pt-3 border-t border-slate-700/50 flex items-center justify-between">
                                  {match.best_market && hasAccess ? (
                                    <span className="text-xs text-emerald-400 font-medium truncate flex items-center gap-1">
                                      <Award className="w-3 h-3" /> {match.best_market}
                                    </span>
                                  ) : (
                                    <span className="text-xs text-slate-500 flex items-center gap-1">
                                      {hasAccess ? <TrendingUp className="w-3 h-3" /> : <LockKeyhole className="w-3 h-3" />}
                                      {hasAccess ? 'Análise pronta' : 'Requer key'}
                                    </span>
                                  )}
                                  <span className={`flex items-center gap-1 text-xs font-semibold transition-all group-hover:gap-2 ${hasAccess ? 'text-emerald-400' : 'text-amber-300'}`}>
                                    {hasAccess ? 'Abrir' : 'Key'} <ChevronRight className="w-3.5 h-3.5" />
                                  </span>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
