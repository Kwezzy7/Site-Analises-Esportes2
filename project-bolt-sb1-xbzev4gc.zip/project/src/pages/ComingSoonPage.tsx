import { ArrowLeft, Bell, CircleDot, Shield, Sparkles } from 'lucide-react';

interface ComingSoonPageProps {
  onBack: () => void;
}

const sports = [
  { name: 'NBA', detail: 'Calendário, forma recente e leitura de jogos', icon: CircleDot, accent: 'border-orange-400/25 bg-orange-400/10 text-orange-300' },
  { name: 'UFC', detail: 'Cards, lutadores e análise de confrontos', icon: Shield, accent: 'border-red-400/25 bg-red-400/10 text-red-300' },
];

export default function ComingSoonPage({ onBack }: ComingSoonPageProps) {
  return (
    <main className="min-h-[calc(100vh-76px)] bg-slate-950 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        <button onClick={onBack} className="mb-8 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-slate-400 transition-colors hover:bg-slate-800 hover:text-white">
          <ArrowLeft className="h-4 w-4" /> Voltar aos jogos
        </button>
        <section className="relative overflow-hidden rounded-[2rem] border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/30 p-6 sm:p-10">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-emerald-500/10 blur-3xl" />
          <div className="relative max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-emerald-300"><Sparkles className="h-3.5 w-3.5" /> Próxima expansão</div>
            <h1 className="mt-5 text-3xl font-bold tracking-tight text-white sm:text-5xl">Mais esportes,<br /><span className="text-emerald-400">mesma leitura.</span></h1>
            <p className="mt-4 max-w-xl text-base leading-7 text-slate-400">Estamos preparando novas modalidades com dados próprios e análises feitas para cada esporte. O futebol continua sendo o centro da plataforma enquanto essa área evolui.</p>
          </div>
          <div className="relative mt-10 grid gap-4 sm:grid-cols-2">
            {sports.map(({ name, detail, icon: Icon, accent }) => (
              <div key={name} className={`rounded-2xl border p-5 ${accent}`}>
                <div className="flex items-center justify-between"><Icon className="h-8 w-8" /><span className="rounded-full bg-slate-950/40 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider">Em breve</span></div>
                <h2 className="mt-8 text-2xl font-bold text-white">{name}</h2>
                <p className="mt-2 text-sm leading-6 text-slate-300">{detail}.</p>
              </div>
            ))}
          </div>
          <div className="relative mt-5 flex items-center gap-3 rounded-2xl border border-slate-700 bg-slate-950/40 p-4 text-sm text-slate-400"><Bell className="h-4 w-4 shrink-0 text-emerald-400" /> A área será liberada quando os dados estiverem prontos para análise.</div>
        </section>
      </div>
    </main>
  );
}
