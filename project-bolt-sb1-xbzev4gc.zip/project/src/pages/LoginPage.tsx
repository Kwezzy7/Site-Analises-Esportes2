import { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  Eye,
  EyeOff,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  Trophy,
  Loader2,
  Activity,
  BarChart3,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const benefits = ['EV+ em destaque', '8 mercados comparados', 'Dados em tempo real'];

export default function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    const action = mode === 'login' ? signIn : signUp;
    const result = await action(email.trim(), password);

    if (result.error) {
      setError(result.error);
      setLoading(false);
    }
  }

  function changeMode(nextMode: 'login' | 'signup') {
    setMode(nextMode);
    setError(null);
  }

  return (
    <main className="auth-shell">
      <div className="auth-orb auth-orb-left" />
      <div className="auth-orb auth-orb-right" />

      <div className="auth-layout">
        <section className="auth-intro">
          <div className="brand-lockup">
            <div className="brand-mark">
              <Trophy className="h-6 w-6" strokeWidth={2.5} />
            </div>
            <div>
              <p className="brand-name">BETBRAIN</p>
              <p className="brand-meta">ANALYTICS&nbsp; / &nbsp;01</p>
            </div>
          </div>

          <div className="intro-copy">
            <div className="eyebrow">
              <Sparkles className="h-3.5 w-3.5" />
              INTELIGÊNCIA DE MERCADO
            </div>
            <h1>
              Leia o jogo.
              <span>Encontre valor.</span>
            </h1>
            <p>
              Um laboratório visual para estudar probabilidades, comparar mercados
              e identificar onde existe vantagem.
            </p>
          </div>

          <div className="login-signal-card">
            <div className="signal-heading"><span><Activity className="h-3.5 w-3.5" /> MONITORAMENTO ATIVO</span><strong>24/7</strong></div>
            <div className="signal-bars"><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /></div>
            <div className="signal-footer"><span>Leitura de mercado em um só lugar</span><BarChart3 className="h-4 w-4" /></div>
          </div>

          <div className="benefits-row">
            {benefits.map((benefit) => (
              <div key={benefit} className="benefit-item">
                <span className="benefit-icon">
                  <Check className="h-3 w-3" strokeWidth={3} />
                </span>
                <span>{benefit}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="auth-card-wrap">
          <div className="auth-card">
            <div className="card-icon">
              <LockKeyhole className="h-5 w-5" />
            </div>
            <h2>{mode === 'login' ? 'Bem-vindo de volta' : 'Comece sua leitura'}</h2>
            <p className="card-subtitle">
              {mode === 'login'
                ? 'Entre para estudar os jogos de hoje.'
                : 'Cadastre-se para acompanhar todas as análises.'}
            </p>

            {error && (
              <div className="auth-error" role="alert">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="auth-form">
              <label className="field-label" htmlFor="email">
                E-MAIL
              </label>
              <div className="field-wrap">
                <Mail className="field-icon h-4 w-4" />
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="seu@email.com"
                  autoComplete="email"
                />
              </div>

              <div className="field-heading">
                <label className="field-label" htmlFor="password">
                  SENHA
                </label>
                {mode === 'login' && <span className="field-hint">Mínimo 6 caracteres</span>}
              </div>
              <div className="field-wrap">
                <LockKeyhole className="field-icon h-4 w-4" />
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="••••••••"
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword((visible) => !visible)}
                  aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>

              <button type="submit" disabled={loading} className="primary-auth-button">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {mode === 'login' ? 'Entrar' : 'Criar minha conta'}
                {!loading && <ArrowRight className="h-4 w-4" />}
              </button>
            </form>

            <div className="auth-switch-row">
              <button
                type="button"
                className={mode === 'login' ? 'switch-button active' : 'switch-button'}
                onClick={() => changeMode('login')}
              >
                Já tenho acesso
              </button>
              <button
                type="button"
                className={mode === 'signup' ? 'switch-button active' : 'switch-button'}
                onClick={() => changeMode('signup')}
              >
                Criar conta
              </button>
            </div>

            <div className="security-note">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Ambiente demonstrativo para estudo de probabilidades.</span>
            </div>
          </div>

          <p className="disclaimer">PROBABILIDADES NÃO SÃO GARANTIAS DE RESULTADO</p>
        </section>
      </div>
    </main>
  );
}
