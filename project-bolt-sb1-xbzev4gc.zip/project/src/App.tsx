import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import LoginPage from '@/pages/LoginPage';
import HomePage from '@/pages/HomePage';
import MatchAnalysisPage from '@/pages/MatchAnalysisPage';
import AdminPage from '@/pages/AdminPage';
import ComingSoonPage from '@/pages/ComingSoonPage';
import PricingPage from '@/pages/PricingPage';

type Page = 'home' | 'match' | 'admin' | 'coming-soon' | 'pricing';

function AppContent() {
  const { session, loading } = useAuth();
  const [page, setPage] = useState<Page>('home');
  const [matchId, setMatchId] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  if (!session) {
    return <LoginPage />;
  }

  function navigate(p: string) {
    if (p === 'home') {
      setPage('home');
      setMatchId(null);
    } else if (p === 'admin') {
      setPage('admin');
    } else if (p === 'coming-soon') {
      setPage('coming-soon');
      setMatchId(null);
    } else if (p === 'pricing') {
      setPage('pricing');
      setMatchId(null);
    }
  }

  function openMatch(id: string) {
    setMatchId(id);
    setPage('match');
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Navbar
        currentPage={page === 'match' ? 'home' : page}
        onNavigate={navigate}
      />
      {page === 'home' && <HomePage onMatchClick={openMatch} />}
      {page === 'match' && matchId && (
        <MatchAnalysisPage matchId={matchId} onBack={() => navigate('home')} />
      )}
      {page === 'admin' && <AdminPage />}
      {page === 'coming-soon' && <ComingSoonPage onBack={() => navigate('home')} />}
      {page === 'pricing' && <PricingPage onBack={() => navigate('home')} />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
