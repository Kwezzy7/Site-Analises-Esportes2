export type UserRole = 'user' | 'admin';

export type KeyStatus = 'active' | 'inactive' | 'revoked';

export interface Profile {
  id: string;
  email: string;
  role: UserRole;
  display_name: string | null;
  avatar_url: string | null;
  license_key: string | null;
  key_status: KeyStatus;
  key_activated_at: string | null;
  created_at: string;
}

export type MatchStatus = 'upcoming' | 'live' | 'finished';

export interface Selection {
  label: string;
  odds: number;
  probability: number;
}

export type MarketType =
  | 'goals_1.5'
  | 'goals_2.5'
  | 'goals_3.5'
  | 'corners_7.5'
  | 'corners_8.5'
  | 'corners_9.5'
  | 'btts'
  | 'result'
  | 'cards_over_3.5'
  | 'cards_over_4.5'
  | 'handicap_-1'
  | 'handicap_+1'
  | 'shots_over_11.5'
  | 'shots_over_13.5'
  | 'shots_on_target_over_4.5'
  | 'fouls_over_22.5';

export interface Match {
  id: string;
  home_team: string;
  away_team: string;
  league: string;
  match_date: string;
  status: MatchStatus;
  home_logo: string;
  away_logo: string;
  best_market: string;
  best_pick: string;
  best_pick_odds: number;
  best_pick_probability: number;
  analysis_summary: string;
  fixture_id: number | null;
  created_at: string;
  updated_at: string;
}

export interface MatchMarket {
  id: string;
  match_id: string;
  market_type: MarketType;
  line: string;
  selections: Selection[];
  recommendation: string;
  created_at: string;
}

export type HistoryType = 'recent' | 'h2h';

export interface MatchHistoryEntry {
  id: string;
  match_id: string;
  history_type: HistoryType;
  team_name: string;
  opponent: string;
  result: 'W' | 'D' | 'L';
  score: string;
  date: string;
  competition: string;
  team_logo?: string | null;
  opponent_logo?: string | null;
}

export const MARKET_LABELS: Record<MarketType, string> = {
  'goals_1.5': 'Gols 1.5',
  'goals_2.5': 'Gols 2.5',
  'goals_3.5': 'Gols 3.5',
  'corners_7.5': 'Escanteios 7.5',
  'corners_8.5': 'Escanteios 8.5',
  'corners_9.5': 'Escanteios 9.5',
  btts: 'Ambas Marcam',
  result: 'Resultado',
  'cards_over_3.5': 'Cartões Acima 3.5',
  'cards_over_4.5': 'Cartões Acima 4.5',
  'handicap_-1': 'Handicap -1 (Casa)',
  'handicap_+1': 'Handicap +1 (Visitante)',
  'shots_over_11.5': 'Finalizações Acima 11.5',
  'shots_over_13.5': 'Finalizações Acima 13.5',
  'shots_on_target_over_4.5': 'Chutes no Gol Acima 4.5',
  'fouls_over_22.5': 'Faltas Acima 22.5',
};

export interface MarketPreset {
  key: MarketType;
  label: string;
  group: string;
  icon: string;
  selections: Selection[];
}

export const MARKET_PRESETS: MarketPreset[] = [
  {
    key: 'result',
    label: 'Resultado',
    group: 'Resultado',
    icon: 'trophy',
    selections: [
      { label: 'Vitória Casa', odds: 0, probability: 0 },
      { label: 'Empate', odds: 0, probability: 0 },
      { label: 'Vitória Visitante', odds: 0, probability: 0 },
      { label: 'Dupla Chance: Casa ou Empate', odds: 0, probability: 0 },
      { label: 'Dupla Chance: Casa ou Visitante', odds: 0, probability: 0 },
      { label: 'Dupla Chance: Empate ou Visitante', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'handicap_-1',
    label: 'Handicap -1 (Casa)',
    group: 'Handicap',
    icon: 'target',
    selections: [
      { label: 'Casa -1 (vence por 2+)', odds: 0, probability: 0 },
      { label: 'Casa não vence por 2+', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'handicap_+1',
    label: 'Handicap +1 (Visitante)',
    group: 'Handicap',
    icon: 'target',
    selections: [
      { label: 'Visitante +1 (empata ou vence)', odds: 0, probability: 0 },
      { label: 'Casa vence', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'goals_1.5',
    label: 'Gols 1.5',
    group: 'Gols',
    icon: 'goal',
    selections: [
      { label: 'Acima 1.5', odds: 0, probability: 0 },
      { label: 'Abaixo 1.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'goals_2.5',
    label: 'Gols 2.5',
    group: 'Gols',
    icon: 'goal',
    selections: [
      { label: 'Acima 2.5', odds: 0, probability: 0 },
      { label: 'Abaixo 2.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'goals_3.5',
    label: 'Gols 3.5',
    group: 'Gols',
    icon: 'goal',
    selections: [
      { label: 'Acima 3.5', odds: 0, probability: 0 },
      { label: 'Abaixo 3.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'btts',
    label: 'Ambas Marcam',
    group: 'Ambas Marcam',
    icon: 'target',
    selections: [
      { label: 'Sim', odds: 0, probability: 0 },
      { label: 'Não', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'corners_7.5',
    label: 'Escanteios 7.5',
    group: 'Escanteios',
    icon: 'flag',
    selections: [
      { label: 'Acima 7.5', odds: 0, probability: 0 },
      { label: 'Abaixo 7.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'corners_8.5',
    label: 'Escanteios 8.5',
    group: 'Escanteios',
    icon: 'flag',
    selections: [
      { label: 'Acima 8.5', odds: 0, probability: 0 },
      { label: 'Abaixo 8.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'corners_9.5',
    label: 'Escanteios 9.5',
    group: 'Escanteios',
    icon: 'flag',
    selections: [
      { label: 'Acima 9.5', odds: 0, probability: 0 },
      { label: 'Abaixo 9.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'cards_over_3.5',
    label: 'Cartões Acima 3.5',
    group: 'Cartões',
    icon: 'card',
    selections: [
      { label: 'Acima 3.5', odds: 0, probability: 0 },
      { label: 'Abaixo 3.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'cards_over_4.5',
    label: 'Cartões Acima 4.5',
    group: 'Cartões',
    icon: 'card',
    selections: [
      { label: 'Acima 4.5', odds: 0, probability: 0 },
      { label: 'Abaixo 4.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'shots_over_11.5',
    label: 'Finalizações Acima 11.5',
    group: 'Finalizações',
    icon: 'target',
    selections: [
      { label: 'Acima 11.5', odds: 0, probability: 0 },
      { label: 'Abaixo 11.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'shots_over_13.5',
    label: 'Finalizações Acima 13.5',
    group: 'Finalizações',
    icon: 'target',
    selections: [
      { label: 'Acima 13.5', odds: 0, probability: 0 },
      { label: 'Abaixo 13.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'shots_on_target_over_4.5',
    label: 'Chutes no Gol Acima 4.5',
    group: 'Finalizações',
    icon: 'target',
    selections: [
      { label: 'Acima 4.5', odds: 0, probability: 0 },
      { label: 'Abaixo 4.5', odds: 0, probability: 0 },
    ],
  },
  {
    key: 'fouls_over_22.5',
    label: 'Faltas Acima 22.5',
    group: 'Estatísticas',
    icon: 'flag',
    selections: [
      { label: 'Acima 22.5', odds: 0, probability: 0 },
      { label: 'Abaixo 22.5', odds: 0, probability: 0 },
    ],
  },
];

export const MARKET_GROUPS: { group: string; items: MarketPreset[] }[] = [
  { group: 'Resultado', items: MARKET_PRESETS.filter((m) => m.group === 'Resultado') },
  { group: 'Handicap', items: MARKET_PRESETS.filter((m) => m.group === 'Handicap') },
  { group: 'Gols', items: MARKET_PRESETS.filter((m) => m.group === 'Gols') },
  { group: 'Ambas Marcam', items: MARKET_PRESETS.filter((m) => m.group === 'Ambas Marcam') },
  { group: 'Escanteios', items: MARKET_PRESETS.filter((m) => m.group === 'Escanteios') },
  { group: 'Cartões', items: MARKET_PRESETS.filter((m) => m.group === 'Cartões') },
  { group: 'Finalizações', items: MARKET_PRESETS.filter((m) => m.group === 'Finalizações') },
  { group: 'Estatísticas', items: MARKET_PRESETS.filter((m) => m.group === 'Estatísticas') },
];

export function getPreset(key: MarketType): MarketPreset | undefined {
  return MARKET_PRESETS.find((m) => m.key === key);
}
