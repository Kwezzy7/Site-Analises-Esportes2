import { useRef, useState } from 'react';
import { Check, Crown, LayoutDashboard, LogOut, Save, Shield, Trophy, Upload, UserRound, X, KeyRound, Sparkles, CreditCard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || 'U';
}

function ProfileAvatar({ url, name, size = 'w-10 h-10' }: { url: string | null; name: string; size?: string }) {
  return url ? (
    <img src={url} alt={name} className={`${size} rounded-xl object-cover border border-slate-600`} />
  ) : (
    <div className={`${size} rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-sm font-bold text-emerald-300`}>
      {initials(name)}
    </div>
  );
}

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const { profile, signOut, updateProfile } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(profile?.avatar_url ?? null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const isAdmin = profile?.role === 'admin';
  const name = profile?.display_name || profile?.email?.split('@')[0] || 'Usuário';
  const hasAccess = isAdmin || profile?.key_status === 'active';

  function openProfile() {
    setDisplayName(profile?.display_name ?? '');
    setPreviewUrl(profile?.avatar_url ?? null);
    setAvatarFile(null);
    setMessage(null);
    setEditing(false);
    setProfileOpen(true);
  }

  function chooseAvatar(file: File | undefined) {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type) || file.size > 2 * 1024 * 1024) {
      setMessage('Use uma imagem JPG, PNG, WEBP ou GIF de até 2 MB.');
      return;
    }
    setAvatarFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setMessage(null);
  }

  async function saveProfile() {
    if (!profile) return;
    setSaving(true);
    setMessage(null);
    let avatarUrl = profile.avatar_url;

    if (avatarFile) {
      const extension = avatarFile.name.split('.').pop()?.toLowerCase() || 'jpg';
      const path = `${profile.id}/avatar-${Date.now()}.${extension}`;
      const { error: uploadError } = await supabase.storage.from('avatars').upload(path, avatarFile, {
        cacheControl: '3600',
        contentType: avatarFile.type,
        upsert: false,
      });
      if (uploadError) {
        setMessage('Não foi possível enviar a foto.');
        setSaving(false);
        return;
      }
      avatarUrl = supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
    }

    const result = await updateProfile(displayName, avatarUrl);
    setSaving(false);
    if (result.error) {
      setMessage(result.error);
      return;
    }
    setEditing(false);
    setAvatarFile(null);
    setMessage('Perfil atualizado.');
  }

  return (
    <nav className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-xl border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[76px] gap-4">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-3 text-white hover:text-emerald-300 transition-colors">
            <span className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-emerald-400" />
            </span>
            <span className="hidden sm:block text-lg font-bold tracking-tight">MatchLab</span>
          </button>

          <div className="flex items-center gap-2 sm:gap-3">
            <button onClick={() => onNavigate('home')} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${currentPage === 'home' ? 'text-emerald-300 bg-emerald-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}>
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden sm:inline">Jogos</span>
            </button>
            <button onClick={() => onNavigate('coming-soon')} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${currentPage === 'coming-soon' ? 'text-emerald-300 bg-emerald-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}>
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">Mais esportes</span>
            </button>
            <button onClick={() => onNavigate('pricing')} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${currentPage === 'pricing' ? 'text-emerald-300 bg-emerald-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}>
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Planos</span>
            </button>
            {isAdmin && (
              <button onClick={() => onNavigate('admin')} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${currentPage === 'admin' ? 'text-emerald-300 bg-emerald-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}>
                <Shield className="w-4 h-4" />
                <span className="hidden sm:inline">Painel</span>
              </button>
            )}

            <button onClick={openProfile} className="flex items-center gap-2.5 rounded-xl px-2 py-1.5 bg-slate-800/80 border border-slate-700 hover:border-emerald-500/50 transition-colors text-left">
              <ProfileAvatar url={profile?.avatar_url ?? null} name={name} size="w-9 h-9" />
              <span className="hidden md:block max-w-[150px]">
                <span className="block text-sm font-semibold text-white truncate">{name}</span>
                <span className={`block text-[10px] font-bold uppercase tracking-wide ${hasAccess ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isAdmin ? 'Administrador' : hasAccess ? 'Acesso ativo' : 'Key pendente'}
                </span>
              </span>
            </button>

            <button onClick={signOut} className="flex items-center gap-2 px-2.5 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:text-red-400 hover:bg-slate-800 transition-colors" title="Sair">
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </div>
      </div>

      {profileOpen && profile && (
        <div className="fixed inset-0 z-50 flex items-start justify-end bg-black/60 backdrop-blur-sm p-4 sm:p-6" onMouseDown={() => setProfileOpen(false)}>
          <div className="w-full max-w-md mt-16 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden" onMouseDown={(event) => event.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-slate-800">
              <div>
                <p className="text-xs uppercase tracking-[0.18em] text-emerald-400 font-bold">Meu perfil</p>
                <h2 className="text-xl font-bold text-white mt-1">Sua conta BetBrain</h2>
              </div>
              <button onClick={() => setProfileOpen(false)} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"><X className="w-5 h-5" /></button>
            </div>

            <div className="p-5 space-y-5">
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-800/70 border border-slate-700">
                <ProfileAvatar url={previewUrl} name={name} size="w-16 h-16" />
                <div className="min-w-0">
                  <p className="text-white font-bold truncate">{name}</p>
                  <p className="text-sm text-slate-400 truncate">{profile.email}</p>
                  <p className="text-xs font-mono text-slate-500 mt-1">ID: {profile.id}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-slate-800/60 border border-slate-700 p-3">
                  <div className="flex items-center gap-2 text-xs text-slate-400"><KeyRound className="w-3.5 h-3.5" /> Licença</div>
                  <p className={`mt-2 text-sm font-bold ${hasAccess ? 'text-emerald-400' : 'text-amber-400'}`}>{isAdmin ? 'Acesso admin' : profile.key_status === 'active' ? 'Ativa' : 'Aguardando liberação'}</p>
                </div>
                <div className="rounded-xl bg-slate-800/60 border border-slate-700 p-3">
                  <div className="flex items-center gap-2 text-xs text-slate-400"><UserRound className="w-3.5 h-3.5" /> Conta</div>
                  <p className="mt-2 text-sm font-bold text-white">{isAdmin ? 'Administrador' : 'Membro'}</p>
                </div>
              </div>

              {!isAdmin && profile.license_key && (
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3">
                  <p className="text-xs text-emerald-300 font-semibold">Sua key de acesso</p>
                  <p className="mt-1 font-mono text-sm text-white tracking-wider">{profile.license_key}</p>
                </div>
              )}

              {editing ? (
                <div className="space-y-4">
                  <label className="block text-sm font-medium text-slate-300">Nome de exibição<input value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={80} className="mt-1.5 w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2.5 text-white outline-none focus:border-emerald-500" placeholder="Como quer ser chamado" /></label>
                  <input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={(event) => chooseAvatar(event.target.files?.[0])} />
                  <button onClick={() => fileInput.current?.click()} className="w-full flex items-center justify-center gap-2 rounded-xl border border-dashed border-slate-600 px-4 py-3 text-sm font-semibold text-slate-300 hover:border-emerald-500 hover:text-white"><Upload className="w-4 h-4" /> Escolher foto</button>
                  {message && <p className="text-sm text-amber-300">{message}</p>}
                  <div className="flex gap-3"><button onClick={() => setEditing(false)} className="flex-1 rounded-xl bg-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:text-white">Cancelar</button><button onClick={saveProfile} disabled={saving} className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-600 disabled:opacity-50">{saving ? 'Salvando...' : <><Save className="w-4 h-4" /> Salvar</>}</button></div>
                </div>
              ) : (
                <div className="space-y-3">
                  {message && <p className="flex items-center gap-2 text-sm text-emerald-300"><Check className="w-4 h-4" />{message}</p>}
                  <button onClick={() => setEditing(true)} className="w-full rounded-xl bg-slate-800 px-4 py-3 text-sm font-semibold text-white hover:bg-slate-700">Editar perfil e foto</button>
                  {!hasAccess && <p className="text-center text-xs leading-5 text-slate-500">Seu perfil está criado, mas o acesso aos jogos será liberado quando um administrador ativar sua key.</p>}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
