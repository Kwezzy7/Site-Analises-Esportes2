import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const BSD_BASE = "https://sports.bzzoiro.com/api/v2";

// ============================================================
// Types
// ============================================================
interface Selection {
  label: string;
  odds: number;
  probability: number;
}

interface MarketDef {
  market_type: string;
  line: string;
  selections: Selection[];
  recommendation: string;
}

interface HistoryDef {
  history_type: 'recent' | 'h2h';
  team_name: string;
  opponent: string;
  result: 'W' | 'D' | 'L';
  score: string;
  date: string;
  competition: string;
  team_logo: string | null;
  opponent_logo: string | null;
}

// BSD API types
interface BSDEvent {
  id: number;
  home_team: { id: number; name: string; logo?: string };
  away_team: { id: number; name: string; logo?: string };
  league: { id: number; name: string; logo?: string; country?: string };
  season?: { id: number; name: string };
  round?: string;
  start_time: string;
  status: string;
  home_score?: number | null;
  away_score?: number | null;
  venue?: string | null;
}

interface BSDPrediction {
  event: number;
  home_win_prob?: number;
  draw_prob?: number;
  away_win_prob?: number;
  over_25_prob?: number;
  under_25_prob?: number;
  over_15_prob?: number;
  under_15_prob?: number;
  over_35_prob?: number;
  under_35_prob?: number;
  btts_yes_prob?: number;
  btts_no_prob?: number;
  corners_over_85_prob?: number;
  corners_under_85_prob?: number;
  cards_over_35_prob?: number;
  cards_under_35_prob?: number;
  predicted_score?: string;
  model?: string;
}

interface BSDH2HMatch {
  id: number;
  home_team: { id: number; name: string; logo?: string };
  away_team: { id: number; name: string; logo?: string };
  home_score: number;
  away_score: number;
  status: string;
  start_time: string;
  league: { id: number; name: string };
  season?: { name: string };
}

interface BSDTeamMatch {
  id: number;
  home_team: { id: number; name: string; logo?: string };
  away_team: { id: number; name: string; logo?: string };
  home_score: number | null;
  away_score: number | null;
  status: string;
  start_time: string;
  league: { id: number; name: string };
}

interface NormalizedEvent {
  id: number;
  homeTeam: string;
  awayTeam: string;
  league: string;
  startTime: string;
  status: string;
  homeLogo: string;
  awayLogo: string;
  homeId: number | null;
  awayId: number | null;
}

// ============================================================
// Helpers
// ============================================================
function oddsFromProb(p: number): number {
  return Math.round((100 / Math.max(p, 5)) * 100) / 100;
}

function mapStatus(status: string): string {
  const normalized = String(status || '').toLowerCase();
  if (['live', 'in_play', 'inplay', 'in-progress'].includes(normalized)) return 'live';
  if (['finished', 'ended', 'post_game', 'completed'].includes(normalized)) return 'finished';
  return 'upcoming';
}

function asTeam(value: any): { id: number | null; name: string; logo: string } {
  if (typeof value === 'string') return { id: null, name: value.trim(), logo: '' };
  return {
    id: Number.isFinite(Number(value?.id)) ? Number(value.id) : null,
    name: String(value?.name ?? value?.team_name ?? '').trim(),
    logo: String(value?.logo ?? value?.logo_url ?? '').trim(),
  };
}

function normalizeEvent(raw: any): NormalizedEvent | null {
  const home = asTeam(raw?.home_team ?? raw?.home ?? raw?.teams?.home);
  const away = asTeam(raw?.away_team ?? raw?.away ?? raw?.teams?.away);
  const rawStartTime = raw?.start_time ?? raw?.kickoff ?? raw?.date ?? raw?.start_at ?? raw?.timestamp;
  const parsedStartTime = typeof rawStartTime === 'number'
    ? new Date(rawStartTime < 10000000000 ? rawStartTime * 1000 : rawStartTime)
    : new Date(String(rawStartTime ?? '').trim());
  const startTime = Number.isNaN(parsedStartTime.getTime()) ? '' : parsedStartTime.toISOString();
  const id = Number(raw?.id ?? raw?.event_id ?? raw?.fixture_id);
  if (!Number.isFinite(id) || !home.name || !away.name || !startTime) return null;
  const league = raw?.league?.name ?? raw?.competition?.name ?? raw?.league_name ?? '';
  return {
    id,
    homeTeam: home.name,
    awayTeam: away.name,
    league: String(league).trim(),
    startTime,
    status: mapStatus(raw?.status?.status ?? raw?.status),
    homeLogo: home.logo,
    awayLogo: away.logo,
    homeId: home.id,
    awayId: away.id,
  };
}

function resultFromScore(home: number, away: number, perspective: 'home' | 'away'): 'W' | 'D' | 'L' {
  if (home === away) return 'D';
  if (perspective === 'home') return home > away ? 'W' : 'L';
  return away > home ? 'W' : 'L';
}

// ============================================================
// API calls
// ============================================================
async function bsdFetch(path: string, apiKey: string): Promise<any | null> {
  try {
    const res = await fetch(`${BSD_BASE}${path}`, {
      headers: { "Authorization": `Token ${apiKey}` },
    });
    if (!res.ok) {
      console.error(`BSD API ${path} returned ${res.status}`);
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error(`BSD fetch error ${path}:`, (e as Error).message);
    return null;
  }
}

// ============================================================
// Build markets from real API prediction data
// ============================================================
function buildMarketsFromPrediction(
  homeTeam: string,
  awayTeam: string,
  pred: BSDPrediction | null,
): MarketDef[] {
  if (!pred) return [];
  const markets: MarketDef[] = [];

  // Resultado
  const homeProb = pred.home_win_prob ?? 0;
  const drawProb = pred.draw_prob ?? 0;
  const awayProb = pred.away_win_prob ?? 0;

  const dcHomeDraw = Math.min(95, homeProb + drawProb);
  const dcHomeAway = Math.min(95, homeProb + awayProb);
  const dcDrawAway = Math.min(95, drawProb + awayProb);

  markets.push({
    market_type: 'result',
    line: '',
    selections: [
      { label: `Vitória ${homeTeam}`, odds: oddsFromProb(homeProb), probability: Math.round(homeProb) },
      { label: 'Empate', odds: oddsFromProb(drawProb), probability: Math.round(drawProb) },
      { label: `Vitória ${awayTeam}`, odds: oddsFromProb(awayProb), probability: Math.round(awayProb) },
      { label: `Dupla Chance: ${homeTeam} ou Empate`, odds: oddsFromProb(dcHomeDraw), probability: Math.round(dcHomeDraw) },
      { label: `Dupla Chance: ${homeTeam} ou ${awayTeam}`, odds: oddsFromProb(dcHomeAway), probability: Math.round(dcHomeAway) },
      { label: `Dupla Chance: Empate ou ${awayTeam}`, odds: oddsFromProb(dcDrawAway), probability: Math.round(dcDrawAway) },
    ],
    recommendation:
      homeProb >= 50
        ? ` ${homeTeam} é favorito com ${Math.round(homeProb)}% de probabilidade segundo o modelo ML. Vitória seca ou dupla chance são as melhores entradas.`
        : awayProb >= 45
        ? ` ${awayTeam} é favorito mesmo fora com ${Math.round(awayProb)}%. Dupla Chance (Empate ou Visitante) reduz o risco.`
        : ` Jogo equilibrado (${Math.round(homeProb)}% vs ${Math.round(awayProb)}%). Dupla chance é a aposta mais segura.`,
  });

  // Gols 1.5
  if (pred?.over_15_prob != null) {
    markets.push({
      market_type: 'goals_1.5',
      line: '1.5',
      selections: [
        { label: 'Acima 1.5', odds: oddsFromProb(pred.over_15_prob), probability: Math.round(pred.over_15_prob) },
        { label: 'Abaixo 1.5', odds: oddsFromProb(pred.under_15_prob ?? 100 - pred.over_15_prob), probability: Math.round(pred.under_15_prob ?? 100 - pred.over_15_prob) },
      ],
      recommendation: pred.over_15_prob >= 75
        ? ` Alta probabilidade (${Math.round(pred.over_15_prob)}%) de 2+ gols. Mercado seguro.`
        : ` Risco de jogo truncado (${Math.round(pred.under_15_prob ?? 100 - pred.over_15_prob)}% para under).`,
    });
  }

  // Gols 2.5
  if (pred?.over_25_prob != null) {
    markets.push({
      market_type: 'goals_2.5',
      line: '2.5',
      selections: [
        { label: 'Acima 2.5', odds: oddsFromProb(pred.over_25_prob), probability: Math.round(pred.over_25_prob) },
        { label: 'Abaixo 2.5', odds: oddsFromProb(pred.under_25_prob ?? 100 - pred.over_25_prob), probability: Math.round(pred.under_25_prob ?? 100 - pred.over_25_prob) },
      ],
      recommendation: pred.over_25_prob >= 60
        ? ` Expectativa de jogo aberto (${Math.round(pred.over_25_prob)}% para 3+ gols).`
        : ` Tendência de jogo fechado (${Math.round(pred.under_25_prob ?? 100 - pred.over_25_prob)}% para under).`,
    });
  }

  // Gols 3.5
  if (pred?.over_35_prob != null) {
    markets.push({
      market_type: 'goals_3.5',
      line: '3.5',
      selections: [
        { label: 'Acima 3.5', odds: oddsFromProb(pred.over_35_prob), probability: Math.round(pred.over_35_prob) },
        { label: 'Abaixo 3.5', odds: oddsFromProb(pred.under_35_prob ?? 100 - pred.over_35_prob), probability: Math.round(pred.under_35_prob ?? 100 - pred.over_35_prob) },
      ],
      recommendation: pred.over_35_prob >= 40
        ? ` Potencial para goleada (${Math.round(pred.over_35_prob)}% para 4+ gols).`
        : ` Difícil ter 4+ gols (${Math.round(pred.under_35_prob ?? 100 - pred.over_35_prob)}% para under).`,
    });
  }

  // BTTS
  if (pred?.btts_yes_prob != null) {
    markets.push({
      market_type: 'btts',
      line: '',
      selections: [
        { label: 'Sim', odds: oddsFromProb(pred.btts_yes_prob), probability: Math.round(pred.btts_yes_prob) },
        { label: 'Não', odds: oddsFromProb(pred.btts_no_prob ?? 100 - pred.btts_yes_prob), probability: Math.round(pred.btts_no_prob ?? 100 - pred.btts_yes_prob) },
      ],
      recommendation: pred.btts_yes_prob >= 55
        ? ` Ambas as equipes devem marcar (${Math.round(pred.btts_yes_prob)}%).`
        : ` Provável que uma não marque (${Math.round(pred.btts_no_prob ?? 100 - pred.btts_yes_prob)}% para não).`,
    });
  }

  // Escanteios 8.5
  if (pred?.corners_over_85_prob != null) {
    const c85Over = pred.corners_over_85_prob;
    const c85Under = pred.corners_under_85_prob ?? 100 - c85Over;
    markets.push({
      market_type: 'corners_8.5',
      line: '8.5',
      selections: [
        { label: 'Acima 8.5', odds: oddsFromProb(c85Over), probability: Math.round(c85Over) },
        { label: 'Abaixo 8.5', odds: oddsFromProb(c85Under), probability: Math.round(c85Under) },
      ],
      recommendation: c85Over >= 55
        ? ` Espera-se 9+ escanteios (${Math.round(c85Over)}%).`
        : ` Tendência de poucos escanteios (${Math.round(c85Under)}% para under).`,
    });
    // Derive 7.5 and 9.5 from 8.5
    const c75Over = Math.min(92, c85Over + 12);
    markets.push({
      market_type: 'corners_7.5',
      line: '7.5',
      selections: [
        { label: 'Acima 7.5', odds: oddsFromProb(c75Over), probability: Math.round(c75Over) },
        { label: 'Abaixo 7.5', odds: oddsFromProb(100 - c75Over), probability: Math.round(100 - c75Over) },
      ],
      recommendation: c75Over >= 65 ? ` Tende a ter muitos escanteios (${Math.round(c75Over)}%).` : ` Possível jogo com poucos escanteios.`,
    });
    const c95Over = Math.max(8, c85Over - 15);
    markets.push({
      market_type: 'corners_9.5',
      line: '9.5',
      selections: [
        { label: 'Acima 9.5', odds: oddsFromProb(c95Over), probability: Math.round(c95Over) },
        { label: 'Abaixo 9.5', odds: oddsFromProb(100 - c95Over), probability: Math.round(100 - c95Over) },
      ],
      recommendation: c95Over >= 35 ? ` Pode passar de 10 escanteios (${Math.round(c95Over)}%).` : ` Difícil atingir dois dígitos.`,
    });
  }

  // Cartões 3.5
  if (pred?.cards_over_35_prob != null) {
    const cd35Over = pred.cards_over_35_prob;
    const cd35Under = pred.cards_under_35_prob ?? 100 - cd35Over;
    markets.push({
      market_type: 'cards_over_3.5',
      line: '3.5',
      selections: [
        { label: 'Acima 3.5 cartões', odds: oddsFromProb(cd35Over), probability: Math.round(cd35Over) },
        { label: 'Abaixo 3.5 cartões', odds: oddsFromProb(cd35Under), probability: Math.round(cd35Under) },
      ],
      recommendation: cd35Over >= 65 ? ` Expectativa de jogo tenso com 4+ cartões (${Math.round(cd35Over)}%).` : ` Tendência de jogo mais limpo (${Math.round(cd35Under)}%).`,
    });
    const cd45Over = Math.max(15, cd35Over - 20);
    markets.push({
      market_type: 'cards_over_4.5',
      line: '4.5',
      selections: [
        { label: 'Acima 4.5 cartões', odds: oddsFromProb(cd45Over), probability: Math.round(cd45Over) },
        { label: 'Abaixo 4.5 cartões', odds: oddsFromProb(100 - cd45Over), probability: Math.round(100 - cd45Over) },
      ],
      recommendation: cd45Over >= 45 ? ` Pode passar de 5 cartões (${Math.round(cd45Over)}%).` : ` Difícil ter 5+ cartões.`,
    });
  }

  // Handicap - derived from win probs
  if (pred?.home_win_prob != null) {
    const hMinus1 = Math.round(Math.max(15, Math.min(70, pred.home_win_prob * 0.65)));
    markets.push({
      market_type: 'handicap_-1',
      line: '-1',
      selections: [
        { label: `${homeTeam} -1 (vence por 2+)`, odds: oddsFromProb(hMinus1), probability: hMinus1 },
        { label: `${homeTeam} não vence por 2+`, odds: oddsFromProb(100 - hMinus1), probability: 100 - hMinus1 },
      ],
      recommendation: hMinus1 >= 50 ? ` ${homeTeam} tem força para vencer por 2+ (${hMinus1}%).` : ` Risco de vitória apertada. Evite.`,
    });
    const aPlus1 = Math.round(Math.min(85, (pred.draw_prob ?? 28) + (pred.away_win_prob ?? 32) + 5));
    markets.push({
      market_type: 'handicap_+1',
      line: '+1',
      selections: [
        { label: `${awayTeam} +1 (empata ou vence)`, odds: oddsFromProb(aPlus1), probability: aPlus1 },
        { label: `${homeTeam} vence`, odds: oddsFromProb(100 - aPlus1), probability: 100 - aPlus1 },
      ],
      recommendation: aPlus1 >= 60 ? ` ${awayTeam} tem ${aPlus1}% de empatar ou vencer.` : ` ${homeTeam} é favorito, evite o +1.`,
    });
  }

  return markets;
}

// ============================================================
// Pick best market — VARY across market types, not just result
// ============================================================
function pickBestMarket(markets: MarketDef[], homeTeam: string, awayTeam: string): {
  market: string;
  pick: string;
  odds: number;
  prob: number;
  summary: string;
} {
  const labels: Record<string, string> = {
    result: 'Resultado',
    'goals_1.5': 'Gols 1.5',
    'goals_2.5': 'Gols 2.5',
    'goals_3.5': 'Gols 3.5',
    btts: 'Ambas Marcam',
    'corners_7.5': 'Escanteios 7.5',
    'corners_8.5': 'Escanteios 8.5',
    'corners_9.5': 'Escanteios 9.5',
    'handicap_-1': 'Handicap -1',
    'handicap_+1': 'Handicap +1',
    'cards_over_3.5': 'Cartões 3.5',
    'cards_over_4.5': 'Cartões 4.5',
    'shots_over_11.5': 'Finalizações 11.5',
    'shots_over_13.5': 'Finalizações 13.5',
    'shots_on_target_over_4.5': 'Chutes no Gol 4.5',
    'fouls_over_22.5': 'Faltas 22.5',
  };

  // Collect ALL selections across all markets with prob >= 55
  const allPicks = markets
    .flatMap((market) => market.selections.map((selection) => ({ market, selection })))
    .filter((item) => item.selection.probability >= 55)
    .sort((a, b) => b.selection.probability - a.selection.probability);

  if (allPicks.length === 0) {
    // Fallback: highest prob
    const everything = markets
      .flatMap((market) => market.selections.map((selection) => ({ market, selection })))
      .sort((a, b) => b.selection.probability - a.selection.probability);
    if (everything.length === 0) {
      return { market: '', pick: '', odds: 0, prob: 0, summary: 'Análise indisponível.' };
    }
    const best = everything[0];
    const marketLabel = labels[best.market.market_type] ?? best.market.market_type;
    return {
      market: marketLabel,
      pick: best.selection.label,
      odds: best.selection.odds,
      prob: best.selection.probability,
      summary: `Leitura principal: ${marketLabel} — ${best.selection.label}. Probabilidade de ${best.selection.probability}% com odd ${best.selection.odds}.`,
    };
  }

  // Pick the top one — this naturally varies because it considers ALL markets equally
  const best = allPicks[0];
  const marketLabel = labels[best.market.market_type] ?? best.market.market_type;

  // Build a contextual summary
  const isResult = best.market.market_type === 'result';
  const isGoals = best.market.market_type.startsWith('goals_');
  const isCorners = best.market.market_type.startsWith('corners_');
  const isCards = best.market.market_type.startsWith('cards_');
  const isHandicap = best.market.market_type.startsWith('handicap_');

  let context = '';
  if (isResult) context = `${homeTeam} x ${awayTeam}: favorito identificado pelo modelo ML da API.`;
  else if (isGoals) context = `${homeTeam} x ${awayTeam}: modelo indica jogo com tendência de gols.`;
  else if (isCorners) context = `${homeTeam} x ${awayTeam}: estatística de escanteios favorável.`;
  else if (isCards) context = `${homeTeam} x ${awayTeam}: expectativa de jogo tenso com cartões.`;
  else if (isHandicap) context = `${homeTeam} x ${awayTeam}: diferença de força entre os times.`;
  else context = `${homeTeam} x ${awayTeam}: mercado com melhor valor identificado pelo modelo.`;

  return {
    market: marketLabel,
    pick: best.selection.label,
    odds: best.selection.odds,
    prob: best.selection.probability,
    summary: `Leitura principal: ${marketLabel} — ${best.selection.label}. Probabilidade de ${best.selection.probability}% com odd ${best.selection.odds}. ${context}`,
  };
}

// ============================================================
// Fetch H2H from API — REAL data only, no fake
// ============================================================
async function fetchH2H(
  homeTeamId: number,
  awayTeamId: number,
  homeTeamName: string,
  awayTeamName: string,
  homeLogo: string,
  awayLogo: string,
  apiKey: string,
): Promise<HistoryDef[]> {
  const data = await bsdFetch(`/events/?home_team=${homeTeamId}&away_team=${awayTeamId}&status=finished&limit=10`, apiKey);
  if (!data?.results) return [];

  const h2h: HistoryDef[] = [];
  for (const m of data.results as BSDH2HMatch[]) {
    if (m.status !== 'finished') continue;
    const homeScore = m.home_score ?? 0;
    const awayScore = m.away_score ?? 0;
    const result = resultFromScore(homeScore, awayScore, 'home');
    h2h.push({
      history_type: 'h2h',
      team_name: homeTeamName,
      opponent: awayTeamName,
      result,
      score: `${homeScore}-${awayScore}`,
      date: m.start_time,
      competition: m.league?.name ?? '',
      team_logo: homeLogo || null,
      opponent_logo: awayLogo || null,
    });
  }
  return h2h;
}

// ============================================================
// Fetch recent form from API — REAL data only
// ============================================================
async function fetchRecentForm(
  teamId: number,
  teamName: string,
  teamLogo: string,
  apiKey: string,
): Promise<HistoryDef[]> {
  // Get team's recent finished matches
  const data = await bsdFetch(`/teams/${teamId}/fixtures/?status=finished&limit=5`, apiKey);
  if (!data?.results) return [];

  const recent: HistoryDef[] = [];
  for (const m of data.results as BSDTeamMatch[]) {
    if (m.status !== 'finished') continue;
    const isHome = m.home_team.id === teamId;
    const myScore = isHome ? (m.home_score ?? 0) : (m.away_score ?? 0);
    const oppScore = isHome ? (m.away_score ?? 0) : (m.home_score ?? 0);
    const result = resultFromScore(myScore, oppScore, isHome ? 'home' : 'away');
    const opponent = isHome ? m.away_team : m.home_team;
    recent.push({
      history_type: 'recent',
      team_name: teamName,
      opponent: opponent.name,
      result,
      score: `${m.home_score}-${m.away_score}`,
      date: m.start_time,
      competition: m.league?.name ?? '',
      team_logo: teamLogo || null,
      opponent_logo: opponent.logo || null,
    });
  }
  return recent;
}

// ============================================================
// Main handler
// ============================================================
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const dateParam = url.searchParams.get("date");
    const autoAnalyze = url.searchParams.get("analyze") === "true";
    const matchId = url.searchParams.get("match_id");
    const homeTeam = url.searchParams.get("home") || "";
    const awayTeam = url.searchParams.get("away") || "";
    const homeLogo = url.searchParams.get("home_logo") || "";
    const awayLogo = url.searchParams.get("away_logo") || "";

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { data: secretData, error: secretError } = await supabase
      .from("app_secrets")
      .select("value")
      .eq("key", "API_FOOTBALL_KEY")
      .maybeSingle();

    if (secretError || !secretData) {
      return new Response(
        JSON.stringify({ error: "Chave da API não configurada." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const apiKey = secretData.value;

    // ── Mode: analyze specific match ──
    if (matchId) {
      // Get match data from DB to find team IDs (stored as fixture_id)
      const { data: matchData } = await supabase
        .from("matches")
        .select("*")
        .eq("id", matchId)
        .maybeSingle();

      if (!matchData) {
        return new Response(JSON.stringify({ error: "Jogo não encontrado." }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Fetch prediction from BSD API using fixture_id if available
      let prediction: BSDPrediction | null = null;
      if (matchData.fixture_id && matchData.fixture_id > 0) {
        const predData = await bsdFetch(`/predictions/?event=${matchData.fixture_id}&limit=1`, apiKey);
        prediction = predData?.results?.[0] ?? null;
      }

      // Build markets from real prediction
      const markets = buildMarketsFromPrediction(homeTeam || matchData.home_team, awayTeam || matchData.away_team, prediction);
      const best = pickBestMarket(markets, homeTeam || matchData.home_team, awayTeam || matchData.away_team);

      // Fetch REAL H2H and recent form from API
      const history: HistoryDef[] = [];
      if (matchData.fixture_id && matchData.fixture_id > 0) {
        // Try to get team IDs from the event
        const eventData = await bsdFetch(`/events/${matchData.fixture_id}/`, apiKey);
        if (eventData) {
          const homeId = eventData.home_team?.id;
          const awayId = eventData.away_team?.id;
          if (homeId && awayId) {
            const [h2h, homeRecent, awayRecent] = await Promise.all([
              fetchH2H(homeId, awayId, matchData.home_team, matchData.away_team, matchData.home_logo, matchData.away_logo, apiKey),
              fetchRecentForm(homeId, matchData.home_team, matchData.home_logo, apiKey),
              fetchRecentForm(awayId, matchData.away_team, matchData.away_logo, apiKey),
            ]);
            history.push(...h2h, ...homeRecent, ...awayRecent);
          }
        }
      }

      // Update match
      await supabase.from("matches").update({
        best_market: best.market,
        best_pick: best.pick,
        best_pick_odds: best.odds,
        best_pick_probability: best.prob,
        analysis_summary: best.summary,
      }).eq("id", matchId);

      // Clear old markets/history
      await supabase.from("match_markets").delete().eq("match_id", matchId);
      await supabase.from("match_history").delete().eq("match_id", matchId);

      // Insert markets
      if (markets.length > 0) {
        const marketRows = markets.map((mk) => ({
          match_id: matchId,
          market_type: mk.market_type,
          line: mk.line,
          selections: JSON.parse(JSON.stringify(mk.selections)),
          recommendation: mk.recommendation,
        }));
        await supabase.from("match_markets").insert(marketRows);
      }

      // Insert history ONLY if we got real data
      if (history.length > 0) {
        const historyRows = history.map((h) => ({
          match_id: matchId,
          history_type: h.history_type,
          team_name: h.team_name,
          opponent: h.opponent,
          result: h.result,
          score: h.score,
          date: h.date,
          competition: h.competition,
          team_logo: h.team_logo,
          opponent_logo: h.opponent_logo,
        }));
        await supabase.from("match_history").insert(historyRows);
      }

      return new Response(
        JSON.stringify({ success: true, match_id: matchId, markets: markets.length, history: history.length, source: 'bsd_api' }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ── Mode: fetch & import matches from BSD API ──
    const targetDate = dateParam || new Date().toISOString().slice(0, 10);

    // BSD events endpoint with date filter
    const eventsData = await bsdFetch(`/events/?date=${targetDate}&limit=200`, apiKey);
    const rawEvents = Array.isArray(eventsData)
      ? eventsData
      : Array.isArray(eventsData?.results)
        ? eventsData.results
        : Array.isArray(eventsData?.data)
          ? eventsData.data
          : Array.isArray(eventsData?.events)
            ? eventsData.events
            : [];

    const bsdEvents = rawEvents
      .map(normalizeEvent)
      .filter((event): event is NormalizedEvent => event !== null);

    if (autoAnalyze && bsdEvents.length > 0) {
      for (const evt of bsdEvents) {
        // Check if match already exists (by fixture_id)
        const { data: existing } = await supabase
          .from("matches")
          .select("id")
          .eq("fixture_id", evt.id)
          .maybeSingle();

        if (existing) continue; // Skip duplicates

        const status = evt.status;
        const homeLogo = evt.homeLogo;
        const awayLogo = evt.awayLogo;

        const { data: inserted, error: insErr } = await supabase
          .from("matches")
          .insert({
            home_team: evt.homeTeam,
            away_team: evt.awayTeam,
            league: evt.league,
            match_date: evt.startTime,
            status,
            home_logo: homeLogo,
            away_logo: awayLogo,
            fixture_id: evt.id,
            best_market: '',
            best_pick: '',
            best_pick_odds: 0,
            best_pick_probability: 0,
            analysis_summary: '',
          })
          .select("id")
          .maybeSingle();

        if (insErr || !inserted) continue;
        const newMatchId = inserted.id;

        // Fetch prediction for this event
        const predData = await bsdFetch(`/predictions/?event=${evt.id}&limit=1`, apiKey);
        const prediction: BSDPrediction | null = predData?.results?.[0] ?? null;

        // Build markets from real prediction
        const markets = buildMarketsFromPrediction(evt.homeTeam, evt.awayTeam, prediction);
        const best = pickBestMarket(markets, evt.homeTeam, evt.awayTeam);

        // Fetch REAL H2H and recent form
        const history: HistoryDef[] = [];
        const homeId = evt.homeId;
        const awayId = evt.awayId;
        if (homeId && awayId) {
          const [h2h, homeRecent, awayRecent] = await Promise.all([
            fetchH2H(homeId, awayId, evt.homeTeam, evt.awayTeam, homeLogo, awayLogo, apiKey),
            fetchRecentForm(homeId, evt.homeTeam, homeLogo, apiKey),
            fetchRecentForm(awayId, evt.awayTeam, awayLogo, apiKey),
          ]);
          history.push(...h2h, ...homeRecent, ...awayRecent);
        }

        // Update match with best pick
        await supabase.from("matches").update({
          best_market: best.market,
          best_pick: best.pick,
          best_pick_odds: best.odds,
          best_pick_probability: best.prob,
          analysis_summary: best.summary,
        }).eq("id", newMatchId);

        // Insert markets
        if (markets.length > 0) {
          const marketRows = markets.map((mk) => ({
            match_id: newMatchId,
            market_type: mk.market_type,
            line: mk.line,
            selections: JSON.parse(JSON.stringify(mk.selections)),
            recommendation: mk.recommendation,
          }));
          await supabase.from("match_markets").insert(marketRows);
        }

        // Insert history ONLY if real data exists
        if (history.length > 0) {
          const historyRows = history.map((h) => ({
            match_id: newMatchId,
            history_type: h.history_type,
            team_name: h.team_name,
            opponent: h.opponent,
            result: h.result,
            score: h.score,
            date: h.date,
            competition: h.competition,
            team_logo: h.team_logo,
            opponent_logo: h.opponent_logo,
          }));
          await supabase.from("match_history").insert(historyRows);
        }
      }

      return new Response(
        JSON.stringify({ imported: true, count: bsdEvents.length, date: targetDate, source: 'bsd_api' }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Return match list without importing
    const matches = bsdEvents.map((f) => ({
      home_team: f.homeTeam,
      away_team: f.awayTeam,
      league: f.league || 'Futebol',
      match_date: f.startTime,
      status: f.status,
      home_logo: f.homeLogo,
      away_logo: f.awayLogo,
      fixture_id: f.id,
    }));

    return new Response(
      JSON.stringify({ matches, date: targetDate, count: matches.length, source: 'bsd_api' }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
// BSD/GoalDir API v2 integration with normalized event responses
