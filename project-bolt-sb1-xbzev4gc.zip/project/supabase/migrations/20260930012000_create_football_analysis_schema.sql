/*
# Football Probability Analysis System - Database Schema

## Overview
Creates the complete database structure for a football betting probability analysis platform with user authentication, admin panel, match management, and market analysis.

## New Tables

1. **profiles** - Extends auth.users with role management (admin/user)
   - `id` (uuid, PK, references auth.users)
   - `email` (text, not null)
   - `role` (text, default 'user' - either 'user' or 'admin')
   - `created_at` (timestamp)

2. **matches** - Football matches/confrontations
   - `id` (uuid, PK)
   - `home_team` (text) - home team name
   - `away_team` (text) - away team name
   - `league` (text) - competition/league name
   - `match_date` (timestamp) - when the match takes place
   - `status` (text, default 'upcoming') - upcoming/live/finished
   - `home_logo` (text) - URL or emoji for home team
   - `away_logo` (text) - URL or emoji for away team
   - `best_market` (text) - admin's recommended best market
   - `best_pick` (text) - admin's recommended pick within that market
   - `best_pick_odds` (numeric) - odds for the best pick
   - `best_pick_probability` (numeric) - probability percentage for best pick
   - `analysis_summary` (text) - admin's written analysis
   - `created_at`, `updated_at` (timestamps)

3. **match_markets** - Market odds and probabilities per match
   - `id` (uuid, PK)
   - `match_id` (uuid, FK to matches, cascade delete)
   - `market_type` (text) - 'goals_1.5', 'goals_2.5', 'goals_3.5', 'corners', 'btts', 'result'
   - `line` (text) - the line value (e.g. "1.5", "8.5")
   - `selections` (jsonb) - array of {label, odds, probability} objects
   - `recommendation` (text) - admin's recommendation for this market
   - `created_at` (timestamp)

4. **match_history** - Recent games for teams in each match
   - `id` (uuid, PK)
   - `match_id` (uuid, FK to matches, cascade delete)
   - `team_name` (text) - which team this history entry belongs to
   - `opponent` (text) - the opponent in that historical game
   - `result` (text) - 'W', 'D', 'L'
   - `score` (text) - e.g. "2-1"
   - `date` (timestamp) - when the historical game took place
   - `competition` (text) - which competition

## Security

- RLS enabled on all tables.
- **profiles**: Users can read their own profile; admins can read all. No client updates allowed (role managed server-side).
- **matches, match_markets, match_history**: All authenticated users can SELECT (read). Only admins can INSERT/UPDATE/DELETE.
- A `SECURITY DEFINER` function `is_admin()` checks the user's role in profiles.
- A trigger `on_auth_user_created` auto-creates a profile with role 'user' on signup.

## Admin Setup
After signup, the admin role is granted by updating the profile row in the database directly.
*/

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- is_admin helper function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- profiles policies
DROP POLICY IF EXISTS "select_own_or_admin_profiles" ON profiles;
CREATE POLICY "select_own_or_admin_profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR is_admin());

-- No INSERT/UPDATE/DELETE policies on profiles from client.
-- Profiles are created by the trigger, roles are managed server-side.

-- ============================================================
-- MATCHES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  home_team text NOT NULL,
  away_team text NOT NULL,
  league text NOT NULL DEFAULT 'Brasileirão',
  match_date timestamptz NOT NULL DEFAULT now() + interval '1 day',
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'live', 'finished')),
  home_logo text DEFAULT '',
  away_logo text DEFAULT '',
  best_market text DEFAULT '',
  best_pick text DEFAULT '',
  best_pick_odds numeric DEFAULT 0,
  best_pick_probability numeric DEFAULT 0,
  analysis_summary text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

-- Read: all authenticated users
DROP POLICY IF EXISTS "select_matches" ON matches;
CREATE POLICY "select_matches"
  ON matches FOR SELECT
  TO authenticated
  USING (true);

-- Write: admin only
DROP POLICY IF EXISTS "insert_matches_admin" ON matches;
CREATE POLICY "insert_matches_admin"
  ON matches FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "update_matches_admin" ON matches;
CREATE POLICY "update_matches_admin"
  ON matches FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "delete_matches_admin" ON matches;
CREATE POLICY "delete_matches_admin"
  ON matches FOR DELETE
  TO authenticated
  USING (is_admin());

-- ============================================================
-- MATCH_MARKETS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS match_markets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  market_type text NOT NULL CHECK (market_type IN ('goals_1.5', 'goals_2.5', 'goals_3.5', 'corners', 'btts', 'result')),
  line text DEFAULT '',
  selections jsonb NOT NULL DEFAULT '[]'::jsonb,
  recommendation text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE match_markets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_match_markets" ON match_markets;
CREATE POLICY "select_match_markets"
  ON match_markets FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_match_markets_admin" ON match_markets;
CREATE POLICY "insert_match_markets_admin"
  ON match_markets FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "update_match_markets_admin" ON match_markets;
CREATE POLICY "update_match_markets_admin"
  ON match_markets FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "delete_match_markets_admin" ON match_markets;
CREATE POLICY "delete_match_markets_admin"
  ON match_markets FOR DELETE
  TO authenticated
  USING (is_admin());

-- ============================================================
-- MATCH_HISTORY TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS match_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  team_name text NOT NULL,
  opponent text NOT NULL,
  result text NOT NULL CHECK (result IN ('W', 'D', 'L')),
  score text DEFAULT '',
  date timestamptz,
  competition text DEFAULT ''
);

ALTER TABLE match_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_match_history" ON match_history;
CREATE POLICY "select_match_history"
  ON match_history FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_match_history_admin" ON match_history;
CREATE POLICY "insert_match_history_admin"
  ON match_history FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "update_match_history_admin" ON match_history;
CREATE POLICY "update_match_history_admin"
  ON match_history FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

DROP POLICY IF EXISTS "delete_match_history_admin" ON match_history;
CREATE POLICY "delete_match_history_admin"
  ON match_history FOR DELETE
  TO authenticated
  USING (is_admin());

-- ============================================================
-- AUTO-CREATE PROFILE ON SIGNUP
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, role)
  VALUES (new.id, new.email, 'user');
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_matches_date ON matches(match_date);
CREATE INDEX IF NOT EXISTS idx_match_markets_match_id ON match_markets(match_id);
CREATE INDEX IF NOT EXISTS idx_match_history_match_id ON match_history(match_id);
