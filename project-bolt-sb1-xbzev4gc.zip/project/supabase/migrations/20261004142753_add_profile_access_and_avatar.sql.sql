/*
# Add protected profile access and avatars

1. Modified Tables
- `profiles.avatar_url` — public avatar image URL for the user's mini profile.
- `profiles.display_name` — optional name shown in the interface.

2. Storage
- Creates the public `avatars` bucket with image-only uploads up to 2 MB.
- Users can manage only files inside their own user-id folder.

3. Security
- Match, market, and history reads now require an active license key or admin role.
- Profile privilege fields remain protected from direct client updates.
- Adds server-side functions for users to update their profile photo/name and for admins to manage license keys.
*/

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS display_name text;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', true, 2097152, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 2097152,
  allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

DROP POLICY IF EXISTS "Public can view avatars" ON storage.objects;
CREATE POLICY "Public can view avatars"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'avatars');

DROP POLICY IF EXISTS "Users upload own avatars" ON storage.objects;
CREATE POLICY "Users upload own avatars"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Users update own avatars" ON storage.objects;
CREATE POLICY "Users update own avatars"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Users delete own avatars" ON storage.objects;
CREATE POLICY "Users delete own avatars"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE OR REPLACE FUNCTION has_active_license(p_user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = p_user_id AND (role = 'admin' OR key_status = 'active')
  );
$$;

CREATE OR REPLACE FUNCTION update_my_profile(p_display_name text, p_avatar_url text)
RETURNS profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_profile profiles;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  UPDATE profiles
  SET display_name = NULLIF(left(trim(coalesce(p_display_name, '')), 80), ''),
      avatar_url = NULLIF(left(trim(coalesce(p_avatar_url, '')), 500), '')
  WHERE id = auth.uid()
  RETURNING * INTO updated_profile;

  RETURN updated_profile;
END;
$$;

CREATE OR REPLACE FUNCTION set_license_key(p_user_id uuid, p_license_key text, p_status text)
RETURNS profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_profile profiles;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin') THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  IF p_status NOT IN ('active', 'inactive', 'revoked') THEN
    RAISE EXCEPTION 'Invalid key status';
  END IF;

  UPDATE profiles
  SET license_key = NULLIF(left(trim(coalesce(p_license_key, '')), 32), ''),
      key_status = p_status,
      key_activated_at = CASE WHEN p_status = 'active' THEN coalesce(key_activated_at, now()) ELSE key_activated_at END
  WHERE id = p_user_id
  RETURNING * INTO updated_profile;

  RETURN updated_profile;
END;
$$;

REVOKE ALL ON FUNCTION has_active_license(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION has_active_license(uuid) TO anon, authenticated;
REVOKE ALL ON FUNCTION update_my_profile(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION update_my_profile(text, text) TO authenticated;
REVOKE ALL ON FUNCTION set_license_key(uuid, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION set_license_key(uuid, text, text) TO authenticated;

DROP POLICY IF EXISTS "select_matches" ON matches;
CREATE POLICY "select_matches_with_access" ON matches FOR SELECT
  TO authenticated USING (has_active_license());

DROP POLICY IF EXISTS "select_match_markets" ON match_markets;
CREATE POLICY "select_match_markets_with_access" ON match_markets FOR SELECT
  TO authenticated USING (has_active_license());

DROP POLICY IF EXISTS "select_match_history" ON match_history;
CREATE POLICY "select_match_history_with_access" ON match_history FOR SELECT
  TO authenticated USING (has_active_license());

DROP POLICY IF EXISTS "update_profiles_admin" ON profiles;
CREATE POLICY "update_profiles_admin" ON profiles FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());
