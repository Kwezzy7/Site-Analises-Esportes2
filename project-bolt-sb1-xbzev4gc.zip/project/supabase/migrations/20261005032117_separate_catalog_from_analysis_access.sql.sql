/*
# Separate public catalog from protected analysis

1. Access behavior
- Authenticated users can see the match catalog, dates, teams, and league names.
- Only users with an active license key or administrator role can read markets and history.

2. Security
- The detailed analysis remains protected by row-level policies in the database.
- This lets the interface show a clear locked preview instead of hiding every match.
*/

DROP POLICY IF EXISTS "select_matches_with_access" ON matches;
DROP POLICY IF EXISTS "select_matches" ON matches;
CREATE POLICY "authenticated_can_view_match_catalog" ON matches FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "select_match_markets_with_access" ON match_markets;
DROP POLICY IF EXISTS "select_match_markets" ON match_markets;
CREATE POLICY "active_users_can_view_match_markets" ON match_markets FOR SELECT
  TO authenticated USING (has_active_license());

DROP POLICY IF EXISTS "select_match_history_with_access" ON match_history;
DROP POLICY IF EXISTS "select_match_history" ON match_history;
CREATE POLICY "active_users_can_view_match_history" ON match_history FOR SELECT
  TO authenticated USING (has_active_license());
