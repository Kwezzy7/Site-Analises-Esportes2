/*
# Add history categories for football analysis

## Overview
Adds a category to each match history record so administrators can manage direct confrontations separately from each team's recent matches.

## Modified table
- `match_history.history_type` (text, default `recent`): identifies `recent` team form or `h2h` direct confrontation.

## Security
- Existing RLS policies remain in place because this is an additive column change only.

## Important notes
1. Existing records are preserved and categorized as `recent`.
2. New direct-confrontation rows can be added with `history_type = 'h2h'`.
*/

ALTER TABLE match_history
  ADD COLUMN IF NOT EXISTS history_type text NOT NULL DEFAULT 'recent';

UPDATE match_history
SET history_type = 'recent'
WHERE history_type IS NULL OR history_type = '';

ALTER TABLE match_history
  DROP CONSTRAINT IF EXISTS match_history_history_type_check;

ALTER TABLE match_history
  ADD CONSTRAINT match_history_history_type_check
  CHECK (history_type IN ('recent', 'h2h'));

CREATE INDEX IF NOT EXISTS idx_match_history_type
  ON match_history(match_id, history_type);
