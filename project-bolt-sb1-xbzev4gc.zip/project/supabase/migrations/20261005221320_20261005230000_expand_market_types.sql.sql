-- Expand market_type to support new markets: handicap, cards, shots, fouls
ALTER TABLE match_markets DROP CONSTRAINT IF EXISTS match_markets_market_type_check;

ALTER TABLE match_markets
  ADD CONSTRAINT match_markets_market_type_check
  CHECK (market_type IN (
    'goals_1.5', 'goals_2.5', 'goals_3.5',
    'corners_7.5', 'corners_8.5', 'corners_9.5',
    'btts', 'result',
    'handicap_-1', 'handicap_+1',
    'cards_over_3.5', 'cards_over_4.5',
    'shots_over_11.5', 'shots_over_13.5', 'shots_on_target_over_4.5',
    'fouls_over_22.5'
  ));
