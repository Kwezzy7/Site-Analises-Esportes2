/*
# Create app_secrets table for storing API keys

1. New Tables
- `app_secrets` — stores API keys and other sensitive configuration
  - `id` (uuid, primary key)
  - `key` (text, unique, not null) — the name of the secret
  - `value` (text, not null) — the secret value
  - `created_at` (timestamptz)

2. Security
- RLS enabled with NO policies — only the service role (which bypasses RLS) can read/write.
- anon and authenticated roles get zero access to this table.
- This keeps API keys safe while the edge function can retrieve them using the service role key.
*/

CREATE TABLE IF NOT EXISTS app_secrets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE app_secrets ENABLE ROW LEVEL SECURITY;
