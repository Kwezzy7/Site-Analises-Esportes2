/*
# Update market_type constraint to support specific market lines

## Changes
- Drops the old CHECK constraint on match_markets.market_type
- Adds a new CHECK constraint allowing these market types:
  - goals_1.5, goals_2.5, goals_3.5
  - corners_7.5, corners_8.5, corners_9.5
  - btts
  - result
- No data loss: existing rows with old 'corners' type will be migrated to 'corners_9.5'
*/

-- Migrate old 'corners' rows to 'corners_9.5'
UPDATE match_markets SET market_type = 'corners_9.5' WHERE market_type = 'corners';

-- Drop old constraint and add new one
ALTER TABLE match_markets DROP CONSTRAINT IF EXISTS match_markets_market_type_check;
ALTER TABLE match_markets ADD CONSTRAINT match_markets_market_type_check
  CHECK (market_type IN (
    'goals_1.5', 'goals_2.5', 'goals_3.5',
    'corners_7.5', 'corners_8.5', 'corners_9.5',
    'btts',
    'result'
  ));
