/*
# Add team_logo and opponent_logo to match_history

1. Modified Tables
- `match_history`
  - `team_logo` (text, nullable): URL or emoji/initial for the team's logo/photo
  - `opponent_logo` (text, nullable): URL or emoji/initial for the opponent's logo/photo
2. Notes
- These columns are optional (nullable) so existing records are unaffected.
- The admin can paste a photo URL or type an emoji/short text as the logo.
- No security changes needed — existing RLS policies already cover all columns.
*/

ALTER TABLE match_history
  ADD COLUMN IF NOT EXISTS team_logo text;

ALTER TABLE match_history
  ADD COLUMN IF NOT EXISTS opponent_logo text;
