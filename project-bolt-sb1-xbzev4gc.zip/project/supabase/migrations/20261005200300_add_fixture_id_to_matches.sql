/*
# Add fixture_id column to matches

1. Changes
- Adds `fixture_id` integer column to `matches` to store the API-Football fixture ID.
- This enables the re-analysis path to fetch real predictions from the API.
2. Security
- No RLS changes; existing policies remain intact.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'fixture_id'
  ) THEN
    ALTER TABLE matches ADD COLUMN fixture_id integer;
  END IF;
END $$;
