/*
# Add license key system to profiles

1. Modified Tables
- `profiles` — adds two new columns:
  - `license_key` (text, unique) — a license key the admin generates and assigns to the user
  - `key_status` (text, default 'inactive') — 'active', 'inactive', or 'revoked'
  - `key_activated_at` (timestamptz) — when the key was activated

2. Security
- No new policies needed; profiles RLS already restricts reads to owner or admin.
- license_key and key_status are managed by admins only (no client write policy).
*/

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS license_key text UNIQUE,
  ADD COLUMN IF NOT EXISTS key_status text NOT NULL DEFAULT 'inactive' CHECK (key_status IN ('active', 'inactive', 'revoked')),
  ADD COLUMN IF NOT EXISTS key_activated_at timestamptz;

-- Function for admin to generate a random license key
CREATE OR REPLACE FUNCTION generate_license_key()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT upper(
    substr(md5(random()::text || clock_timestamp()::text), 1, 4) || '-' ||
    substr(md5(random()::text || clock_timestamp()::text), 1, 4) || '-' ||
    substr(md5(random()::text || clock_timestamp()::text), 1, 4)
  );
$$;
